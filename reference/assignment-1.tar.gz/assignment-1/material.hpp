/*
 * material.hpp
 *
 *  Created on: Sep 14, 2009
 *      Author: etiene
 *
 *  This file is part of assignment-1.
 *
 *  assignment-1 is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  assignment-1 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with assignment-1.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef MATERIAL_HPP_
#define MATERIAL_HPP_

#include "common.hpp"
#include "singleton.hpp"

namespace ogl
{

class Material
{
public:
	Material()
	{
		initParam();
	}
	Material(const Material& mat)
	{
		initParam(mat);
	}
	~Material()
	{
	}

	GLfloat mAmbient[4];
	GLfloat mDiffuse[4];
	GLfloat mSpecular[4];
	GLfloat mEmission[4];
	GLfloat mShininess[1];
	GLenum mFace;

	inline
	void setAmbientReflectance(const GLfloat ambient[4])
	{
		ogl::copy(ambient, mAmbient);
		glMaterialfv(mFace, GL_AMBIENT, mAmbient);
		isAmbientDefined = true;
	}
	inline
	void setDiffuseReflectance(const GLfloat diffuse[4])
	{
		ogl::copy(diffuse, mDiffuse);
		glMaterialfv(mFace, GL_DIFFUSE, mDiffuse);
		isDiffuseDefined = true;
	}
	inline
	void setSpecularReflectance(const GLfloat specular[4])
	{
		ogl::copy(specular, mSpecular);
		glMaterialfv(mFace, GL_SPECULAR, mSpecular);
		isSpecularDefined = true;
	}
	inline
	void setEmissionReflectance(const GLfloat emission[4])
	{
		ogl::copy(emission, mEmission);
		glMaterialfv(mFace, GL_EMISSION, mEmission);
		isEmissionDefined = true;
	}
	inline
	void setShininess(const GLfloat shininess[1])
	{
		mShininess[0] = shininess[0];
		glMaterialfv(mFace, GL_SHININESS, mShininess);
		isShininessDefined = true;
	}
	inline
	void setFaceModel(GLenum face)
	{
		mFace = face;
	}

	inline
	void setState() const
	{
		if(isAmbientDefined)
			glMaterialfv(mFace, GL_AMBIENT, mAmbient);
		if(isDiffuseDefined)
			glMaterialfv(mFace, GL_DIFFUSE, mDiffuse);
		if(isSpecularDefined)
			glMaterialfv(mFace, GL_SPECULAR, mSpecular);
		if(isEmissionDefined)
			glMaterialfv(mFace, GL_EMISSION, mEmission);
		if(isShininessDefined)
			glMaterialfv(mFace, GL_SHININESS, mShininess);
	}

protected:
	void initParam()
	{
		mSpecular[0] = 0.0;
		mSpecular[1] = 0.0;
		mSpecular[2] = 0.0;
		mSpecular[3] = 1.0;

		mDiffuse[0] = 0.0;
		mDiffuse[1] = 0.0;
		mDiffuse[2] = 0.0;
		mDiffuse[3] = 1.0;

		mAmbient[0] = 0.0;
		mAmbient[1] = 0.0;
		mAmbient[2] = 0.0;
		mAmbient[3] = 1.0;

		mEmission[0] = 0.0;
		mEmission[1] = 0.0;
		mEmission[2] = 0.0;
		mEmission[3] = 1.0;

		mFace = GL_FRONT;

		mShininess[0] = 0.0;

		isAmbientDefined = false;
		isDiffuseDefined = false;
		isSpecularDefined = false;
		isEmissionDefined = false;
		isShininessDefined = false;
	}

	void initParam(const Material& mat)
	{
		ogl::copy(mat.mSpecular, mSpecular);
		ogl::copy(mat.mDiffuse, mDiffuse);
		ogl::copy(mat.mAmbient, mAmbient);
		ogl::copy(mat.mEmission, mEmission);
		mFace = mat.mFace;
		mShininess[0] = mat.mShininess[0];

		isAmbientDefined = mat.isAmbientDefined;
		isDiffuseDefined = mat.isDiffuseDefined;
		isSpecularDefined = mat.isSpecularDefined;
		isEmissionDefined = mat.isEmissionDefined;
		isShininessDefined = mat.isShininessDefined;
	}

	bool isAmbientDefined;
	bool isDiffuseDefined;
	bool isSpecularDefined;
	bool isEmissionDefined;
	bool isShininessDefined;


};

}

#endif /* MATERIAL_HPP_ */
