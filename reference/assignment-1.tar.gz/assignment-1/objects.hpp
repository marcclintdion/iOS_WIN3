/*
 * objects.hpp
 *
 *  Created on: Sep 14, 2009
 *      Author: etiene
 *
 *  This file is part of assignment-1.
 *
 *  assignment-1 is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  assignment-1 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with assignment-1.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef OBJECTS_HPP_
#define OBJECTS_HPP_

namespace ogl
{

static pfxe::Mesh* sphere = 0;

static GLfloat wall_vertices[] = {0.0, 0.0, 0.0,
								  1.0, 0.0, 0.0,
								  1.0, 1.0, 0.0,
								  0.0, 1.0, 0.0,
								  0.0, 0.0, 1.0,
								  1.0, 0.0, 1.0,
								  1.0, 1.0, 1.0,
								  0.0, 1.0, 1.0};
static GLfloat wall_normals[] = {-1.0, -1.0, -1.0,
								 +1.0, -1.0, -1.0,
								 +1.0, +1.0, -1.0,
								 -1.0, +1.0, -1.0,
								 -1.0, -1.0, +1.0,
								 +1.0, -1.0, +1.0,
								 +1.0, +1.0, +1.0,
								 -1.0, +1.0, +1.0};

static GLfloat wall_texture_front[] = {0.0, 0.0,
									   0.0, 0.0,
									   0.0, 0.0,
									   0.0, 0.0,
									   0.0, 0.0,
									   1.0, 0.0,
									   1.0, 1.0,
									   0.0, 1.0};
static GLfloat wall_texture_back[] = {0.0, 0.0,
									  1.0, 0.0,
									  1.0, 1.0,
									  0.0, 1.0,
									  0.0, 0.0,
									  0.0, 0.0,
									  0.0, 0.0,
									  0.0, 0.0};
static GLfloat wall_texture_left[] = {0.0, 0.0,
									  0.0, 0.0,
									  0.0, 0.0,
									  0.0, 1.0,
									  1.0, 0.0,
									  0.0, 0.0,
									  0.0, 0.0,
									  1.0, 1.0};
static GLfloat wall_texture_right[] = {0.0, 0.0,
									   0.0, 0.0,
									   0.0, 1.0,
									   0.0, 0.0,
									   0.0, 0.0,
									   1.0, 0.0,
									   1.0, 1.0,
									   0.0, 0.0};
static GLfloat wall_texture_upper[] = {0.0, 0.0,
									   0.0, 0.0,
									   0.0, 0.0,
									   1.0, 0.0,
									   0.0, 0.0,
									   0.0, 0.0,
									   0.0, 1.0,
									   1.0, 1.0};
static GLfloat wall_texture_bottom[] = {0.0, 0.0,
									    1.0, 0.0,
									    0.0, 0.0,
									    0.0, 0.0,
									    0.0, 1.0,
									    1.0, 1.0,
									    0.0, 0.0,
									    0.0, 0.0};
static GLfloat wall_texture_bottoms[] = {0.0, 0.0,
									    1.0, 0.0,
									    0.0, 0.0,
									    0.0, 0.0,
									    0.0, 1.0,
									    1.0, 1.0,
									    0.0, 0.0,
									    0.0, 0.0};

static GLubyte front_face[] = {4, 5, 6, 7};
static GLubyte back_face[] = {0, 3, 2, 1};
static GLubyte left_face[] = {0, 4, 7, 3};
static GLubyte right_face[] = {1, 2, 6, 5};
static GLubyte upper_face[] = {7, 6, 2, 3};
static GLubyte bottom_face[] = {0, 1, 5, 4};

void reset(GLfloat* begin, GLfloat* end, GLfloat* ref)
{
	while(begin != end)
	{
		*begin = *ref;
		++begin;
		++ref;
	}
}

void translate(GLfloat* begin, GLfloat* end, GLfloat tx, GLfloat ty)
{
	while(begin != end)
	{
		*begin     += tx;
		*(++begin) += ty;
		++begin;
	}
}

void scale(GLfloat* begin, GLfloat* end, GLfloat s)
{
	while(begin != end)
	{
		*begin -= 0.5;
		*begin *= s;
		*begin += 0.5 * s;
		*begin -= (s - 1.0) * 0.5;
		++begin;
	}
}

};

#endif /* OBJECTS_HPP_ */
