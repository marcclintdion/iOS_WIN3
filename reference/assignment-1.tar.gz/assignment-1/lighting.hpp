/*
 * lighting.hpp
 *
 *  Created on: Sep 14, 2009
 *      Author: etiene
 *
 *  This file is part of assignment-1.
 *
 *  assignment-1 is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  assignment-1 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with assignment-1.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef LIGHTING_HPP_
#define LIGHTING_HPP_

#include <map>
#include <vector>

#include "singleton.hpp"

namespace ogl
{

class Lighting : public ogl::Singleton<Lighting>
{
public:

	GLenum mShadeModel;
	GLfloat ambientLight[4];

	std::map<GLenum, std::vector<GLfloat> > light2pos;

	inline
	void setShadeModel(GLenum model)
	{
		mShadeModel = model;
		glShadeModel(mShadeModel);
	}

	inline
	void setLightModelAmbientLight(const GLfloat ambientLight[4])
	{
		glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientLight);
	}

	inline
	void setLightPosition(const int i, const GLfloat pos[4])
	{
		light2pos[getLightId(i)] = std::vector<GLfloat>(pos, pos + 4);
		glLightfv(getLightId(i), GL_POSITION, pos);
	}

	inline
	void setLightDiffuse(const int i, const GLfloat diffuse[4])
	{
		glLightfv(getLightId(i), GL_DIFFUSE, diffuse);
	}

	inline
	void setLightSpecular(const int i, const GLfloat specular[4])
	{
		glLightfv(getLightId(i), GL_SPECULAR, specular);
	}


	inline
	void enableLight(int i) const
	{
		glEnable(getLightId(i));
	}
	inline
	void disableLight(int i) const
	{
		glDisable(getLightId(i));
	}
	inline
	void enableLighting() const
	{
		glEnable(GL_LIGHTING);
	}
	inline
	void disableLighting() const
	{
		glDisable(GL_LIGHTING);
	}

	inline
	void enableNormalize() const
	{
		glEnable(GL_NORMALIZE);
	}

	inline
	void disableNormalize() const
	{
		glDisable(GL_NORMALIZE);
	}

	inline
	void drawLight(int i)
	{
		asserLight(i);

		const std::vector<GLfloat>& pos = light2pos[getLightId(i)];

		glBegin(GL_POINTS);
		glVertex3f(pos[0], pos[1], pos[2]);
		glEnd();
	}

	inline
	void drawAllLightSources()
	{

		std::map<GLenum, std::vector<GLfloat> >::iterator start, end;
		start = light2pos.begin();
		end   = light2pos.end();
		for(; start != end; ++start)
		{
			const std::vector<GLfloat>& pos = start->second;
			glBegin(GL_POINTS);
			glVertex3f(pos[0], pos[1], pos[2]);
			glEnd();
		}
	}

protected:
	Lighting()
	{
		initParam();
	}
	Lighting(const Lighting& mat)
	{
		assert(0 && "Copy construction not defined");
	}
	~Lighting()
	{
	}

	inline
	void initParam()
	{
	}

	inline
	GLenum getLightId(int i) const
	{
		if(i == 0) return GL_LIGHT0;
		else if(i == 1) return GL_LIGHT1;

		assert(0 && "Only one ligh source was defined.");
	}

	void asserLight(int i)
	{
		assert(light2pos.find(getLightId(i)) != light2pos.end() &&
				"The requested light was not enabled.");
	}

	friend class ogl::Singleton<ogl::Lighting>;

};

};

#endif /* LIGHTING_HPP_ */
