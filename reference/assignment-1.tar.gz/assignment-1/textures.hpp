/*
 * texture.hpp
 *
 *  Created on: Sep 14, 2009
 *      Author: etiene
 *
 *  This file is part of assignment-1.
 *
 *  assignment-1 is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  assignment-1 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with assignment-1.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef TEXTURE_HPP_
#define TEXTURE_HPP_

#include <cstdlib>

#include <string>
#include <rgb_reader.h>

#include "common.hpp"
#include "singleton.hpp"

namespace ogl
{

class Textures : public ogl::Singleton<Textures>
{
public:
	Textures()
	{
		initParam();
	}
	Textures(const Textures& mat)
	{
		assert(0 && "No copy contructor defined for Texture");
	}
	~Textures()
	{
		freeImage();
	}

	inline
	void loadRGBTexture(const char* filename)
	{
		freeImage();

		mCurrentImage = read_texture(filename, &mWidth, &mHeight, &mComponents);
		assert(mCurrentImage && "Problem loading image");
	}

	inline
	void unloadTexture()
	{
		freeImage();
	}


	inline
	void bindTexture(int idx, GLenum target)
	{
		glBindTexture(target, mTextureNames[idx]);
	}

	inline
	void setTexturesParameter(GLenum target, GLenum pname, GLint param)
	{
		glTexParameteri(target, pname, param);
	}

	inline
	void generateTexturesNames(GLsizei n)
	{
		if(mTextureNames)
		{
			delete [] mTextureNames;
			assert(0 && "Aside from freeing mTextureName \
					we need to free OpenGL internal texture names");
		}

		mTextureNames = new GLuint[n];
		glGenTextures(n, mTextureNames);
	}

	inline
	void setTextureEnvironment(GLenum target, GLenum pname, GLfloat param)
	{
		glTexEnvf(target, pname, param);
	}

	inline
	void enableTexture(GLenum target)
	{
		glEnable(target);
	}

	inline
	void disableTexture(GLenum target)
	{
		glDisable(target);
	}

	inline
	void set2DTexture(GLint internalFormat,
			GLint border, GLenum format, GLenum type)
	{
		assert(mCurrentImage && "No texture loaded");
		glTexImage2D(GL_TEXTURE_2D,
				0, mComponents, mWidth, mHeight, border,
				format, type, mCurrentImage);
	}


	inline
	void set2DMipmapTexture(const char* mask, int n,
			GLint internalFormat,
			GLint border, GLenum format, GLenum type)
	{
		for(int i = 0; i < n; ++i)
		{
			char filename[256];
			sprintf(filename, mask, i);
			loadRGBTexture(filename);

			glTexImage2D(GL_TEXTURE_2D, i,
				mComponents, mWidth, mHeight, border,
				format, type, mCurrentImage);
		}
	}

protected:
	void initParam()
	{
		mCurrentImage = 0;
		mTextureNames = 0;
	}

	void freeImage()
	{
		if(mCurrentImage) free(mCurrentImage);
	}


	GLuint* mTextureNames;
	unsigned int* mCurrentImage;
	int mWidth, mHeight, mComponents;

	friend class ogl::Singleton<Textures>;
};

};


#endif /* TEXTURE_HPP_ */
