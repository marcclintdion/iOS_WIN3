/*
 * camera.hpp
 *
 *  Created on: Sep 10, 2009
 *      Author: etiene
 *
 *  This file is part of assignment-1.
 *
 *  assignment-1 is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  assignment-1 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with assignment-1.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef CAMERA_HPP_
#define CAMERA_HPP_

#include "singleton.hpp"

namespace ogl
{

class Camera : public ogl::Singleton<Camera>
{
public:

	GLdouble mAspectRatio;
	GLdouble mNear;
	GLdouble mFar;
	GLdouble mFovy;

	GLdouble mEye[3];
	GLdouble mFocus[3];
	GLdouble mUp[3];

	inline void setPerspectiveProjection() const
	{
		gluPerspective(mFovy, mAspectRatio, mNear, mFar);
	}


	inline void takeALook() const
	{
		gluLookAt(mEye[0], mEye[1], mEye[2],
				  mFocus[0], mFocus[1], mFocus[2],
				  mUp[0], mUp[1], mUp[2]);
	}

protected:
	Camera()
	{
		initParam();
	}
	Camera(const Camera& cam)
	{
		assert(0 && "Copy construction not defined");
	}
	~Camera()
	{
	}

	void initParam()
	{
		mAspectRatio = 1.0;
		mNear = 0.1;
		mFar  = 100.0;
		mFovy = 45.0;

		mEye[0] = 0.0;
		mEye[1] = 0.0;
		mEye[2] = 10.0;

		mFocus[0] = 0.0;
		mFocus[1] = 0.0;
		mFocus[2] = 0.0;

		mUp[0] = 0.0;
		mUp[1] = 1.0;
		mUp[2] = 0.0;
	}

	friend class ogl::Singleton<ogl::Camera>;
};

};

#endif /* CAMERA_HPP_ */
