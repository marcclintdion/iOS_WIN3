/*
 * common.hpp
 *
 *  Created on: Sep 14, 2009
 *      Author: etiene
 *
 *  This file is part of assignment-1.
 *
 *  assignment-1 is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  assignment-1 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with assignment-1.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef COMMON_HPP_
#define COMMON_HPP_

#include <cmath>

namespace ogl
{

static double PI = 4.0 * atan(1.0);
static double HALF_PI = 2.0 * atan(1.0);
static double TWO_PI = 8.0 * atan(1.0);

template<class _real>
void copy(const _real src[4], _real dst[4])
{
	dst[0] = src[0];
	dst[1] = src[1];
	dst[2] = src[2];
	dst[3] = src[3];
}

};

#endif /* COMMON_HPP_ */
