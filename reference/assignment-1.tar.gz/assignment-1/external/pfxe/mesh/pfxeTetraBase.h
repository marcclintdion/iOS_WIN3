#ifndef _PFXETETRABASE_H_
#define _PFXETETRABASE_H_

#include <iostream>
#include <vector>

#include "defines.h"
#include "pfxeComposite.h"

using std::vector;

namespace pfxe
{

/*!
 *  \brief Base class for meshes faces
 *
 *  You shold inherit this class to create an face
 */
template<class Traits>
class TetraBase : public MeshComponent
{
public:

    //! Type of the instancied edge.
    /*! This tells to user wich type the tetrahedron is set to */
    typedef typename Traits::tetra Tetra;

    //! Type of the instancied edge.
    /*! This tells to user wich type the edge is set to */
    typedef typename Traits::face Face;

    //! Type of the Vertex to be intancied
    typedef typename Traits::vertex Vertex;

    //! Type of the Edge to be intancied
    typedef typename Traits::edge Edge;

    //! Type of an array of Vertex's to be intancied
    typedef typename Traits::pfxeVertices Vertices;

    //! Type of an array of Edges to be intancied
    typedef typename Traits::pfxeEdges Edges;

    //! Type of a iterator to Vertices
    typedef typename vector<typename Traits::vertex*>::iterator
		VertexStarIterator;

    //! Type of a iterator to Vertices
    typedef typename vector<typename Traits::vertex*>::const_iterator
		ConstVertexStarIterator;

    //! Type of a iterator to Edges
    typedef typename Edges::iterator EdgeIterator;

public:
    //! Default constructos
	TetraBase();

    //! Default constructos
	TetraBase(const TetraBase& tetra);

    //! Destructor
    virtual ~TetraBase();

    /*!
     *  \brief Overloaded [] operator. Returns a pointer to an Vertex type
     *  \param idx Index of one of the Vertices of the face
     *  \return The Vertex in idx
     *  \sa getVertex()
     */
    inline Vertex& operator[](const tIndex &idx);

    //! Returns a pointer to an Vertex type
    /*! \sa operator[]() */
    inline Vertex& getVertex(const tIndex &idx) const;

    //! Returns a pointer to an Vertex type
    /*! \sa operator[]() */
    inline Vertex* getVertexPtr(const tIndex &idx) const;

    //! Add a vertex to the face
    inline void addVertex(Vertex *);

    //! Begin an iterator for a Vertex array
    inline ConstVertexStarIterator beginVertex() const;

    //! End of an iterator for a Vertex array
	inline ConstVertexStarIterator endVertex() const;

    //! Begin an iterator for a Vertex array
	inline VertexStarIterator beginVertex();

     //! End of an iterator for a Vertex array
	inline VertexStarIterator endVertex();

	//! @brief Size of vertex list
	inline tSize size();


	//! @brief Check a tetrahedra orientation.
	//!
	//! @return It returns 0 if all faces point outside the volume, 1 if all
	//!         faces points toward inside and 2 otherwise
	inline int checkOrientation();


    virtual tUInt sizeInBytes()
    {
        tSize size = 0;
        for(unsigned int i = 0; i < vertexArray.size(); ++i)
            size += sizeof(Vertex*);

        return sizeof(TetraBase) + size;
    }


	tIndex		id;    //!< Id of the face

    vector<Vertex*> vertexArray; //!< Vertex array of the face
};


#include "pfxeTetraBase.tpl"

}; //namespace

#endif //_PFXETETRABASE_H_
