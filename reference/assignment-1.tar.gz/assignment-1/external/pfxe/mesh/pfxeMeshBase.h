#ifndef _PFXEMESHBASE_H_
#define _PFXEMESHBASE_H_

#include <iostream>
#include <string>
#include <vector>
#include <cassert>
#include <cmath>
#include <limits>

#include "pfxeComposite.h"
#include "pfxeMeshInterface.h"
#include "defines.h"

using std::vector;
using std::sqrt;

#ifdef PFXE_SELF_RENDERING
#include <GL/gl.h>
#endif

namespace pfxe
{

//! TODO Create a script to generate Traits automatically

/*! \brief Base class for meshes
 *
 *  You shold inherit this class to create a mesh
 */
template<class Traits>
class MeshBase : public MeshInterface, public MeshComponent
{
public:
    //! Type of the mesh to be instancied.
    /*! This tells to user wich type the mesh is set to */
    typedef typename Traits::mesh Mesh;

    //! Type of the Vertex to be intancied
    typedef typename Traits::vertex Vertex;

    //! Type of the Edge to be intancied
    typedef typename Traits::edge Edge;

    //! Type of the Face to be intancied
    typedef typename Traits::face Face;

	//! Type of the Face to be intancied
    typedef typename Traits::tetra Tetra;

    //! Type of an array of Vertex's to be intancied
    typedef typename Traits::pfxeVertices Vertices;

    //! Type of an array of Edges to be intancied
    typedef typename Traits::pfxeEdges Edges;

    //! Type of an array of Faces to be intancied
    typedef typename Traits::pfxeFaces Faces;

    //! Type of an array of Faces to be intancied
    typedef typename Traits::pfxeTetras Tetras;

    //! Type of a iterator to Vertices
    typedef typename Vertices::iterator VertexIterator;

    //! Type of a iterator to Edges
    typedef typename Edges::iterator EdgeIterator;

    //! Type of a iterator to Faces
    typedef typename Faces::iterator FaceIterator;

    //! Type of a iterator to Faces
    typedef typename Tetras::iterator TetraIterator;

    //! Type of a iterator to Vertices
    typedef typename vector<Vertex*>::iterator VertexStarIterator;

    //! Type of a iterator to Vertices
    typedef typename vector<Face*>::iterator  FaceStarIterator;


public:
    //! Default constructor
    MeshBase(const std::string &meshName);

    //! Virtual destructor
    virtual ~MeshBase();

    //! Get the Vertices of the mesh
	inline Vertices& vertices();

    //! Get the edges of the mesh
	inline Edges &edges();

    //! Get the faces of the mesh
	inline Faces &faces();

	//! Get the faces of the mesh
	inline Tetras &tetras();

    //! Get an especific Vertex on mesh (search by id)
    inline Vertex& getVertex(const tUIndex idx);

    //! Get an especific Vertex on mesh (search by id)
    inline Vertex* getVertexPtr(const tUIndex &idx) const;

    //! Get an especific Edge on mesh (search by id)
	inline Edge& getEdge(const tUIndex &idx) const;

    //! Get an especific Edge on mesh (search by id)
    inline Edge* getEdgePtr(const tUIndex &idx) const;

    //! Get an especific Face on mesh (search by id)
    inline Face& getFace(const tUIndex &idx) const;

    //! Get an especific Face on mesh (search by id)
    inline Face* getFacePtr(const tUIndex &idx) const;


    //! \brief Add a triangular face to the mesh
    //!
    //! \return Returns an interator to the inserted element
	FaceIterator addFace(const tIndex &,
                         const tIndex &,
                         const tIndex &);

//    //! Add a four-side face to the mesh
//    void addFace(const tIndex &,
//    			 const tIndex &,
//    			 const tIndex &,
//    			 const tIndex &);

    //! \brief Add a vertex to the mesh
    //!
    //! \return This method returns an iterator to the inserted vertex
    //!
    //! \remarks This method will automatically set the member attribute 'id' of
    //! Vertex. So be aware while using this field.
    inline VertexIterator addVertex(const tReal &x, const tReal &y, const tReal &z);



    //! @brief Add a tetrahedron to the mesh
    inline TetraIterator addTetra(const tIndex id1,
				  const tIndex id2,
				  const tIndex id3,
				  const tIndex id4);


    //! \brief Add a vertex to the mesh
    //!
    //! UNUSED
    //!
    //! \return This method returns an iterator to the inserted vertex
    //!
    //! \remarks This method will automatically set the member attribute 'id' of
    //! Vertex. So be aware while using this field.
    //inline VertexIterator addVertex(tIndex i,
    //    const tReal &x, const tReal &y, const tReal &z);


//    //! \brief Add a vertex to the mesh
//    //!
//    //! UNUSED
//    //!
//    //! \param v A previously allocated vertex
//    //!
//    //! \return This method returns an iterator to the inserted vertex
//    //!
//    //! \remarks This method will automatically set the member attribute 'id' of
//    //! Vertex. So be aware while using this field.
//    inline VertexIterator addVertex(Vertex *v);


    //! \brief Add an edge to the mesh
    //!
    //! This method allocates a vertex for the mesh. If the vertex is already on
    //! mesh then it is not inserted and an iterator to the element is
    //! returned. Otherwise, a iterator for the inserted element is returned.
    //!
    //! @param v1Id The index of the first vertex on the edge
    //! @param v2Id The index of the second vertex on the edge
    //! @param face Pointer to a face where we search for the edge
    //!
    //! \return Returns an iterator to inserted vertex.
    //! \remark This is still experimental and should not be used
    inline EdgeIterator addEdge(const tIndex &v1Id, const tIndex &v2Id, Face *face);


    //! \brief Add an edge to the mesh
    //!
    //! This method allocates a vertex for the mesh. If the vertex is already on
    //! mesh then it is not inserted and an iterator to the element is
    //! returned. Otherwise, an iterator for the inserted element is returned.
    //!
    //! \return Returns an iterator to inserted vertex.
    inline EdgeIterator addEdge(Vertex* v1, Vertex* v2);


    //! \brief Add an edge to the mesh
    //!
    //! This method allocates a vertex for the mesh. If the vertex is already on
    //! mesh then it is not inserted and an iterator to the element is
    //! returned. Otherwise, an iterator for the inserted element is returned.
    //!
    //! \return Returns an iterator to inserted vertex.
    inline EdgeIterator addEdge(Vertex& v1, Vertex& v2);


    //! \brief Add an edge to the mesh
    //!
    //! This method allocates a vertex for the mesh. If the vertex is already on
    //! mesh then it is not inserted and an iterator to the element is
    //! returned. Otherwise, an iterator for the inserted element is returned.
    //!
    //! \return Returns an iterator to inserted vertex.
    inline EdgeIterator addEdge(const tIndex &idx1, const tIndex &idx2);


    //! \brief Set the capacity of the vertex array
    //!
    //! \param _vSize The size of the vertex array
    inline void setVerticesCapacity(tSize _vSize);



    //! @brief Get the mesh centroid
    //!
    //! @param cx X-coordinate of mesh centroid
    //! @param cy Y-coordinate of mesh centroid
    //! @param cz Z-coordinate of mesh centroid
    inline void meshCentroid(tReal& cx, tReal& cy, tReal& cz);


    //! @brief Get model bounds
    //! This method returns the box that contains the given mesh
    //!
    //! @param xmin X-coordinate of the lower-left-back box point
    //! @param ymin Y-coordinate of the lower-left-back box point
    //! @param zmin Z-coordinate of the lower-left-back box point
    //! @param xmax X-coordinate of the upper-rigt-front box point
    //! @param ymax Y-coordinate of the upper-rigt-front box point
    //! @param zmax Z-coordinate of the upper-rigt-front box point
    inline void getModelBounds(tReal& xmin, tReal& ymin, tReal& zmin,
							   tReal& xmax, tReal& ymax, tReal& zmax);


    //! @brief Check consistency of meshes tetrahedra.
    //!
    //! @return It returns 0 if no correction was necessary or 1 otherwise
    inline int correctTetraConsistency();

    //! @brief Check the tetra orientation.
    //!
    //! @param tetra Input tetrahedra
    //! @return It returns 1 if is positive oriented or -1 ortherwise
    inline int tetraOrientation(Tetra& tetra);

    //! \brief Returns the number of vertices
    inline tSize sizeV() const;

    //! \brief Returns the number of edges
    inline tSize sizeE() const;

    //! \brief Returns the number of faces
    inline tSize sizeF() const;

    //! \brief Returns the number of faces
    inline tSize sizeT() const;

    //! Begin an iterator for a Vertex array
    inline VertexIterator beginVertex();

    //! End of an iterator for a Vertex array
    inline VertexIterator endVertex();

    //! Begin of an iterator for a Edge array
    inline EdgeIterator beginEdge();

    //! End of an iterator for a Edge array
    inline EdgeIterator endEdge();

    //! Begin of an iterator for a Face array
    inline FaceIterator beginFace();

    //! End of an iterator for a Face array
    inline FaceIterator endFace();

    //! Begin of an iterator for a Face array
    inline TetraIterator beginTetra();

    //! End of an iterator for a Face array
    inline TetraIterator endTetra();



#ifdef PFXE_SELF_RENDERING
    virtual void drawSolid();
    virtual void drawSmooth();
    virtual void drawWire();
    virtual void drawTetras();
    virtual void drawMeshPoints();
    virtual void drawVerticesNormal();
    virtual void drawFacesNormal();
#endif //PFXE_SELF_RENDERING


    virtual tUInt sizeInBytes()
    {
        tUInt size = 0;
        VertexIterator itv;
        EdgeIterator ite;
        FaceIterator itf;

        for(itv = beginVertex(); itv != endVertex(); ++itv)
            size += itv->sizeInBytes();

//        for(ite = beginEdge(); ite != endEdge(); ++ite)
//            size += ite->sizeInBytes();

        for(itf = beginFace(); itf != endFace(); ++itf)
            size += itf->sizeInBytes();

        return size + sizeof(MeshBase) + sizeof(MeshComponent);
    }

protected:
	Vertices       cVertices; //!< Array of Vertices
	Edges          cEdges;    //!< Array of Edges
	Faces          cFaces;    //!< Array of Faces
	Tetras	       cTetras;   //!< Array of Tetrahedrons
};

#include "pfxeMeshBase.tpl"


};

#endif //_PFXEMESHBASE_H_
