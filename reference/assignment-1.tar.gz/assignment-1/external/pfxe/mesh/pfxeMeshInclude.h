#ifndef PFXEMESHINCLUDE_H_
#define PFXEMESHINCLUDE_H_

#include "pfxeMeshBase.h"
#include "pfxeVertexBase.h"
#include "pfxeEdgeBase.h"
#include "pfxeFaceBase.h"

#include "pfxeMeshManager.h"

#include "pfxeMesh.h"
#include "pfxeVertex.h"
#include "pfxeEdge.h"
#include "pfxeFace.h"

#include "readers/pfxeReaderOBJBase.h"
#include "readers/pfxeReaderOBJ.h"

#endif /*PFXEMESHINCLUDE_H_*/
