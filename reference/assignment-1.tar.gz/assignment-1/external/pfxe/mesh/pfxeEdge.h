#ifndef PFXEEDGE_H_
#define PFXEEDGE_H_

#include "pfxeEdgeBase.h"
#include "pfxeMeshTraits.h"

namespace pfxe
{

/*!
 *  \brief Default edge class for mesh construction
 */
class Edge : public EdgeBase<MeshTraits>
{
public:
    Edge()
    {
    }

    Edge(const Edge& edge) : EdgeBase<MeshTraits>::EdgeBase(edge)
    {
    }

    virtual tUInt sizeInBytes()
    {
        return sizeof(Edge) + EdgeBase<MeshTraits>::sizeInBytes();
    }
};

}; //namespace

#endif /*PFXEEDGE_H_*/
