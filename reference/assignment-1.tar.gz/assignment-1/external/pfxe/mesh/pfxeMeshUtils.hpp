#ifndef PFXEMESHUTILS_HPP_
#define PFXEMESHUTILS_HPP_

namespace pfxe
{

//! @brief Check if a given type is currently allocated
//!
//! @param m A given mesh to ve verified
//! @param showMessage
template <class T>
int 
isAllocated(T* m, bool showMessage = true)
{
	if(!m)
	{
		std::cout << "This type is not currently allocated. ";
		std::cout << "Please, alloc it first." << std::endl;
		
		return 0;
	}
	return 1;
}

}; // namespace

#endif /*PFXEMESHUTILS_HPP_*/
