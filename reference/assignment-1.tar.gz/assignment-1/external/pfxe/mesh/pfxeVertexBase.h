#ifndef _PFXEVERTEXBASE_H_
#define _PFXEVERTEXBASE_H_

#include <iostream>
#include <vector>
#include <cmath>

#include "defines.h"
#include "pfxeComposite.h"

using std::vector;

namespace pfxe
{

/*!
 *  \brief Base class for meshes vertex's
 *
 *  You shold inherit this class to create an vertex
 */
template<class Traits>
class VertexBase : public MeshComponent
{
public:
    //! Type of the mesh to be instancied.
    /*! This tells to user wich type the mesh is set to */
    typedef typename Traits::mesh Mesh;

    //! Type of the Vertex to be intancied
    typedef typename Traits::vertex Vertex;

    //! Type of the Edge to be intancied
    typedef typename Traits::edge Edge;

    //! Type of the Face to be intancied
    typedef typename Traits::face Face;

    //! Type of the Tetra to be intancied
    typedef typename Traits::tetra Tetra;

    //! Type of an array of Vertex's to be intancied
    typedef typename Traits::pfxeVertices Vertices;

    //! Type of an array of Edges to be intancied
    typedef typename Traits::pfxeEdges Edges;

    //! Type of an array of Faces to be intancied
    typedef typename Traits::pfxeFaces Faces;

    //! Type of a iterator to Vertices
    typedef typename Vertices::iterator VertexIterator;

    //! Type of a iterator to Edges
    typedef typename Edges::iterator EdgeIterator;

    //! Type of a iterator to Faces
    typedef typename Faces::iterator FaceIterator;

    //! Type of a iterator to Faces
    typedef typename vector<typename Traits::face*>::iterator FaceStarIterator;

    typedef typename vector<typename Traits::tetra*>::iterator TetraStarIterator;

public:

    //! \brief Default constructor
    //!
    //! The values of some public attributes are automatically set to
    //!   - id = -1;
    //!   - x = 0.0;
    //!   - y = 0.0;
    //!   - z = 0.0;
    //!   - fSize = eSize = 0.
    VertexBase();

    VertexBase(const Vertex& vertex);

    //! Default destructor
    virtual ~VertexBase();

    /*!
     *  \brief Overloaded [] operator. Returns one of the coordinates
     *  \param idx Index of one of the three vertex coordinates
     *  \return Returns a reference to a coordinate (x, y, or z)
     */
	inline tReal &operator[](const tIndex &idx);


    //! Add a face to vertex star
    inline void	addFace(Face* face);

    //! Add a face to vertex star
    inline void addTetra(Tetra* tetra);

    //! Add an edge to vertex star
    inline void addEdge(Edge *edge);

    //! Get a face from vertex start
    inline Face& getFace(tIndex idx);

    //! Get a face from vertex start
    inline Face* getFacePtr(tIndex idx);

    //! Get the normal of a point N = (Nx, nY, nZ)
    //!
    //! \param nX X component of the normal N
    //! \param nY Y component of the normal N
    //! \param nZ Z component of the normal N
    //!
    //! \remarks The returned normal vector is normalized vector
    inline void getNormal(tReal &nX, tReal &nY, tReal &nZ) const;

    //! \brief Calculates a normal vector (normalized) of this vertex
    //! \todo Find other ways to calculate normal (through plane's equation)
    inline void calculateNormal();

    //! Begin of an iterator for a Edge array
    inline EdgeIterator beginEdge();

    //! End of an iterator for a Edge array
    inline EdgeIterator endEdge();

    //! Begin of an iterator for a Edge array
    inline FaceStarIterator beginFace();

    //! End of an iterator for a Edge array
    inline FaceStarIterator endFace();


    virtual tUInt sizeInBytes()
    {
        return sizeof(VertexBase) + sizeof(MeshComponent);
    }


    //! Vertex Id
    //! \todo Maybe this index should be protected instead public
    tIndex          id;

    tReal			x; //!< x-coordinate

    tReal			y; //!< y-coordinate

    tReal			z; //!< z-coordinate


    tReal           nx; //!< normal x-component

    tReal           ny; //!< normal y-component

    tReal           nz; //!< normal z-component


    tSize			fSize; //!< Number of faces that shares this vertex

//    tSize           eSize; //!< Number of edges that shares this vertex
protected:

    std::vector<Face *>   faceArray; //!< Faces that belongs to vertex star
    std::vector<Tetra *>  tetraArray; //!< Faces that belongs to vertex star
//    std::vector<Edge *> edgeArray; //!< Edges that belongs to vertex star
};

#include "pfxeVertexBase.tpl"

};

#endif //_PFXEVERTEXBASE_H_
