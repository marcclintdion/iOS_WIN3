#ifndef PFXEVERTEX_H_
#define PFXEVERTEX_H_

#include "pfxeVertexBase.h"
#include "pfxeMeshTraits.h"

namespace pfxe
{

/*! 
 *  \brief Default vertex class for mesh construction
 */
class Vertex : public VertexBase<MeshTraits>
{
public:
    Vertex()
    {
    }
    
    Vertex(const Vertex& vertex) : VertexBase<MeshTraits>(vertex)
    {
    }
    
    virtual tUInt sizeInBytes()
    {   
        return sizeof(Vertex) + VertexBase<MeshTraits>::sizeInBytes();
    }
};

}; //namespace

#endif /*PFXEVERTEX_H_*/
