#ifndef _MESH_DEFINES_H_
#define _MESH_DEFINES_H_

#include "../defines.h"

#endif //_MESH_DEFINES_H_
