#ifndef PFXEFACE_H_
#define PFXEFACE_H_

#include "pfxeFaceBase.h"
#include "pfxeMeshTraits.h"

namespace pfxe
{

/*!
 *  \brief Default face class for mesh construction
 */
class Face : public FaceBase<MeshTraits>
{
public:
    Face()
    {
    }

    Face(const Face& face) : FaceBase<MeshTraits>(face)
    {
    }

    virtual tUInt sizeInBytes()
    {
        return sizeof(Face) + FaceBase<MeshTraits>::sizeInBytes();
    }
};

}; //namespace

#endif /*PFXEFACE_H_*/
