#ifndef PFXEMESHTRAITS_H_
#define PFXEMESHTRAITS_H_

#include <vector>

namespace pfxe
{

class Vertex;
class Edge;
class Face;
class Tetra;
class Mesh;

/*! \struct MeshTraits
 *  \brief Mesh Traits for the necessaries types to the mesh
 */
struct MeshTraits
{
    //! Default Mesh
    typedef Mesh mesh;

    //! Default vertex for the mesh
	typedef Vertex vertex;

    //! Default edge for the mesh
	typedef Edge edge;

    //! Default face for the mesh
	typedef Face face;

	//! Default tetrahedron for the mesh
	typedef Tetra tetra;

    //! Default Vertex array for the mesh
	typedef std::vector<vertex> pfxeVertices;

    //! Default Edge array for the mesh
	typedef std::vector<edge *> pfxeEdges;

    //! Default Face array for the mesh
	typedef std::vector<face> pfxeFaces;

	//! Default Tetrahedron array for the mesh
	typedef std::vector<tetra> pfxeTetras;
};

}; // namespace

#endif /*PFXETRAITS_H_*/
