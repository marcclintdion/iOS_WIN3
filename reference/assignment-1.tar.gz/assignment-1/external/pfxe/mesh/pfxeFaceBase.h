#ifndef _PFXEFACEBASE_H_
#define _PFXEFACEBASE_H_

#include <iostream>
#include <vector>

#include "defines.h"
#include "pfxeComposite.h"

using std::vector;

namespace pfxe
{

/*! 
 *  \brief Base class for meshes faces
 * 
 *  You shold inherit this class to create an face
 */
template<class Traits>
class FaceBase : public MeshComponent
{
public:
    //! Type of the instancied edge.
    /*! This tells to user wich type the edge is set to */
    typedef typename Traits::face Face;
    
    //! Type of the Vertex to be intancied
    typedef typename Traits::vertex Vertex;
    
    //! Type of the Edge to be intancied
    typedef typename Traits::edge Edge; 
    
    //! Type of an array of Vertex's to be intancied
    typedef typename Traits::pfxeVertices Vertices;
    
    //! Type of an array of Edges to be intancied
    typedef typename Traits::pfxeEdges Edges;
    
    //! Type of a iterator to Vertices
	typedef typename vector<typename Traits::vertex*>::iterator VertexStarIterator;
    
    //! Type of a iterator to Edges
    typedef typename Edges::iterator EdgeIterator;
    
public:
    //! Default constructos
    FaceBase();
    
    //! Default constructos
    FaceBase(const Face& face);
    
    //! Destructor
    virtual ~FaceBase();
    
    /*! 
     *  \brief Overloaded [] operator. Returns a pointer to an Vertex type
     *  \param idx Index of one of the Vertices of the face
     *  \return The Vertex in idx
     *  \sa getVertex()
     */
    inline Vertex& operator[](const tIndex &idx);
    
    //! Returns a pointer to an Vertex type
    /*! \sa operator[]() */
    inline Vertex& getVertex(const tIndex &idx) const;
    
    
    //! Returns a pointer to an Vertex type
    /*! \sa operator[]() */
    inline Vertex* getVertexPtr(const tIndex &idx) const;
    
    
    //! Returns a pointer to an edge of the face
    inline Edge& getEdge(const tIndex &idx) const;
    
    
    //! Returns a pointer to an edge of the face
    inline Edge* getEdgePtr(const tIndex &idx) const;
    
    //! Add a vertex to the face
    inline void addVertex(Vertex *);
    
    //! Add an edge to the face
    inline void addEdge(Edge *);
    
    //! \brief Get the face normal
    //! \todo Implementation of a better method for get normals
    //! \todo The return normals must be normalized
	virtual void getNormal(tReal &nX, tReal &nY, tReal &nZ) const;

    //! \brief Calculates a normal vector (normalized) of this vertex
    //! \todo Find other ways to calculate normal (through plane's equation)
    inline void calculateNormal();

    //! Get the face centroid
    void centroid(tReal &cX, tReal &cY, tReal &cZ) const;

    //! Begin an iterator for a Vertex array
	inline VertexStarIterator beginVertex();    
    
     //! End of an iterator for a Vertex array
	inline VertexStarIterator endVertex();


    virtual tUInt sizeInBytes()
    {
        tSize size = 0;
        for(unsigned int i = 0; i < vertexArray.size(); ++i)
            size += sizeof(Vertex*);
            
        return sizeof(FaceBase) + size;
    }
    

	tIndex		id;    //!< Id of the face
	tSize		vSize; //!< Number of vertices of the face
//	tSize		eSize; //!< Numver of edges of the face
	
    tReal nx, ny, nz;
    
    vector<Vertex*> vertexArray; //!< Vertex array of the face
private:
	
//    Edges edgeArray;      //!< Edge array of the face
};


#include "pfxeFaceBase.tpl"

}; //namespace

#endif //_PFXEFACEBASE_H_
