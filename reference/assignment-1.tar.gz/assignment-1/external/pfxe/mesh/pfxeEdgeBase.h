#ifndef _PFXEEDGEBASE_H_
#define _PFXEEDGEBASE_H_

#include <iostream>
#include <vector>

#include "defines.h"
#include "pfxeComposite.h"

namespace pfxe
{

/*! 
 *  \brief Base class for meshes edges
 * 
 *  You shold inherit this class to create an edge
 */
template<class Traits>
class EdgeBase : public MeshComponent
{
public:
        //! Type of the mesh to be instancied.
    /*! This tells to user wich type the mesh is set to */
    typedef typename Traits::mesh Mesh;
    
    //! Type of the Vertex to be intancied
    typedef typename Traits::vertex Vertex;
    
    //! Type of the Edge to be intancied
    typedef typename Traits::edge Edge;
    
    //! Type of the Face to be intancied
    typedef typename Traits::face Face; 
    
    //! Type of an array of Vertex's to be intancied
    typedef typename Traits::pfxeVertices Vertices;
    
    //! Type of an array of Edges to be intancied
    typedef typename Traits::pfxeEdges Edges;
    
    //! Type of an array of Faces to be intancied
    typedef typename Traits::pfxeFaces Faces;
    
    //! Type of a iterator to Vertices
    typedef typename Vertices::iterator VertexIterator;
    
    //! Type of a iterator to Edges
    typedef typename Edges::iterator EdgeIterator;
    
    //! Type of a iterator to Faces
    typedef typename Faces::iterator FaceIterator;
	
public:
    //! Default constructor
	EdgeBase();
    
    //! Copy constructor
    EdgeBase(const EdgeBase& edge);
    
    //! Virtual destructor
	virtual ~EdgeBase();
	   
        
    /*! \brief Overloaded [] operator. Returns a pointer to an Vertex type
     *  \param idx Index of one of the two Vertex that share the edge
     *  \return The Vertex in idx
     *  \sa getVertex()
     */
	inline Vertex &operator[](const tIndex &idx) const;


    //! Returns the vector that represents the edge
	inline void getEdge(tReal &x, tReal &y, tReal &z) const;


    //! Returns a pointer to an Vertex type
    /*! \sa operator[]() */
	inline Vertex&  getVertex(const tIndex &) const;
	
    
    //! Returns a pointer to an Vertex type
    /*! \sa operator[]() */
    inline Vertex* getVertexPtr(const tIndex &) const;
    
    
    //! Returns a face that share the edge
	inline Face& getFace(const tIndex &) const;	
	
    
    //! Returns a face that share the edge
    inline Face* getFacePtr(const tIndex &) const;
    
    //! Set the two Vertex's that share the edge
	inline void setVertex(Vertex *, Vertex *);
	
    
    //! Add a face that share this vertex
	void addFace(Face *);
    
    virtual tUInt sizeInBytes()
    {
        return sizeof(EdgeBase) + sizeof(MeshComponent);
    }
    
    
	tIndex id; //!< Id of the edge
	tSize fSize; //!< Number of faces that share the edge
	
protected:    
	Vertex *v1; //!< Firts Vertex of the edge
	Vertex *v2;	//!< Second Vertex of the edge

	Faces faceArray; //!< Array of faces that sares this vertex
};

#include "pfxeEdgeBase.tpl"


}; //namespace

#endif //_PFXEEDGEBASE_H_
