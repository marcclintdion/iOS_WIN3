#ifndef PFXEPLYWRITER_H_
#define PFXEPLYWRITER_H_

#include <fstream>
#include "mesh/pfxeMeshUtils.hpp"

namespace pfxe
{

template <class Traits>
class WriterPLY
{
public:
    //! Type of the mesh to be instancied.
    /*! This tells to user wich type the mesh is set to */
    typedef typename Traits::mesh Mesh;
    
    //! Type of the Vertex to be instancied
    typedef typename Traits::vertex Vertex;
    
    //! Type of the Edge to be instancied
    typedef typename Traits::edge Edge;
    
    //! Type of the Face to be intancied
    typedef typename Traits::face Face; 
    
    //! Type of an array of Vertex's to be instancied
    typedef typename Traits::pfxeVertices Vertices;
    
    //! Type of an array of Edges to be instancied
    typedef typename Traits::pfxeEdges Edges;
    
    //! Type of an array of Faces to be instancied
    typedef typename Traits::pfxeFaces Faces;
    
    
public:
    //! \brief Writes a PLY file
    //!
    //! This static function is responsable to write PLY files.
    //!
    //! \param mesh The mesh already allocated. Note that this function will
    //! fail case the mesh is not preallocated;
    //!
    //! \param fileName Name of the file to be written
    //!
    //! \return returns the status of the writing process: 0 means success and
	//! any other value otherwise
    static int Write(Mesh* mesh, const std::string fileName);
};

#include "pfxePLYWriter.tpl"

}; //namespace



#endif /*PFXEPLYWRITER_H_*/
