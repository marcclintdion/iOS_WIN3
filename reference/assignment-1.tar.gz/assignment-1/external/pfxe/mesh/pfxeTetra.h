#ifndef PFXETETRA_H_
#define PFXETETRA_H_

#include "pfxeTetraBase.h"
#include "pfxeMeshTraits.h"

namespace pfxe
{

/*!
 *  \brief Default face class for mesh construction
 */
class Tetra : public TetraBase<MeshTraits>
{
public:
	Tetra()
    {
    }

	Tetra(const Tetra& tetra) : TetraBase<MeshTraits>(tetra)
    {
    }

    virtual tUInt sizeInBytes()
    {
        return sizeof(Tetra) + TetraBase<MeshTraits>::sizeInBytes();
    }
};

}; //namespace

#endif /*PFXETETRA_H_*/
