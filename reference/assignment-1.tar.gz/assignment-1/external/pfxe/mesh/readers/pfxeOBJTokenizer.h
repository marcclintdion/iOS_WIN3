// FACE (f) - information of a face
// NUMBER (n) - information of a number
// SLASH (/) - slash, it separates vertex normal and vertex texture
// COMMENTARY (#) - commentary

// FACE = FACEMARK ENTRY ENTRY ENTRY *{ENTRY} 
// ENTRY = NUMBER [SLASH [NUMBER] [SLASH NUMBER]]
// NUMBER = *{0-9}
// SLASH = /
// FACEMARK = f

// TODO
// TEXTURECOORDINATES = TEXTUREMARK U [V] [W]
// TEXTUREMARK = vt
// U = float
// V = float
// W = float

// USEMTL = MTLMARK STRING
// MTLMARK = usemtl
// STRING = *{a-zA-Z} 

#ifndef PFXEOBJTOKENIZER_H_
#define PFXEOBJTOKENIZER_H_

#include "../defines.h"

#include <fstream>
#include <string>
#include <vector>

using std::ifstream;
using std::string;
using std::vector;

namespace pfxe
{

class Tokenizer
{
public:
    enum TokenType
    {
        NUMBER = 0,
        SLASH = 1,
        FACEMARK = 2,
        UNKNOWN = 3,
        EOFSTATE = 4
    };
     
public:
    Tokenizer(ifstream& _file);    
    ~Tokenizer();
    
    TokenType getNext();    
    TokenType getToken();
    string getTokenValue();
    
    
protected:
    
    void setState(char ch);
    
    TokenType stateEOF();    
    TokenType stateSLASH();    
    TokenType stateFACEMARK();    
    TokenType stateNUMBER();    
    TokenType stateUNKNOWN();
    
    void stateCOMMENT();
    
    ifstream& file;
    TokenType state, last;
    string tokenValue;
    
};

class SyntaticAnalysis
{
public:
    typedef vector<tUIndex>::const_iterator VertexIndicesIterator;
public:
    SyntaticAnalysis(ifstream& _file);
    ~SyntaticAnalysis();
    
    Tokenizer::TokenType readFile();


    VertexIndicesIterator beginVertexIndices();
    VertexIndicesIterator endVertexIndices();
    
protected:
    void facet(Tokenizer::TokenType& type);
    void entry(Tokenizer::TokenType& type);
    void unknown(Tokenizer::TokenType& type);
    
    bool match(const Tokenizer::TokenType& expected, 
        Tokenizer::TokenType& given);

protected:
    ifstream& file;
    Tokenizer tokens;
    string tokenString;
    
    vector<tUIndex> facesVertices;
    
    
};

}; // namespace

#endif /*PFXEOBJTOKENIZER_H_*/
