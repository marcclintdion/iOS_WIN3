#ifndef _PFXEMESHREADEROBJBASE_H_
#define _PFXEMESHREADEROBJBASE_H_

#include <iostream>
#include <set>
#include <string>
#include <fstream>
#include <cassert>
#include <cctype>


#include "pfxeOBJTokenizer.h"


#ifdef GNU_GCC
#include <ext/hash_map>
#endif

using std::ifstream;
using std::isdigit;
using std::string;

namespace pfxe
{


/*! 
 * \brief Base lass responsable for loading the mesh
 */
template<class Traits>
class ReaderOBJBase
{
public:
    //! Type of the mesh to be instancied.
    /*! This tells to user wich type the mesh is set to */
    typedef typename Traits::mesh Mesh;
    
    //! Type of the Vertex to be instancied
    typedef typename Traits::vertex Vertex;
    
    //! Type of the Edge to be intancied
    typedef typename Traits::edge Edge;
    
    //! Type of the Face to be intancied
    typedef typename Traits::face Face; 
    
    //! Type of an array of Vertex's to be intancied
    typedef typename Traits::pfxeVertices Vertices;
    
    //! Type of an array of Edges to be intancied
    typedef typename Traits::pfxeEdges Edges;
    
    //! Type of an array of Faces to be intancied
    typedef typename Traits::pfxeFaces Faces;
    
public:
//    static MeshBase<> *Open(const std::string);
//    static int OpenPointBased(MeshBase<> *, const std::string);

    //! \brief To Open a OBJ file
    //!
    //! This static function is responsable to Open OBJ files.
    //!
    //! \param mesh The mesh already allocated. Note that this function will
    //! fail case the mesh is not preallocated;
    //!
    //! \param fileName The name of the OBJ file
    //!
    //! \return returns the status of the loading process: 0 in case of fail and
    //! 1 in case success
    static int Open(Mesh *mesh, const std::string fileName);


    //! \brief To Open a OBJ file
    //!
    //! This static function is responsable to Open OBJ files.
    //!
    //! \param mesh The mesh already allocated. Note that this function will
    //! fail case the mesh is not preallocated;
    //!
    //! \param fileName The name of the OBJ file
    //!
    //! \return returns the status of the loading process: 0 in case of fail and
    //! 1 in case success
    static int OpenIMH(Mesh *mesh, const std::string fileName);

	/*
    // A function object for Comparison
    struct CmpEdges
    {
        bool operator()(const Edge& u, const Edge& v)
        {
            if(&u[0] == &v[0] && &u[1] == &v[1]) return true;
            if(&u[1] == &v[0] && &u[0] == &v[1]) return true;
            
            return false;
        };
    };
    
    // A function object for find hash values
    struct HashFnc
    {
        std::size_t operator()(const Edge& u) const
        {
            __gnu_cxx::hash<const char*> fnc;            
            const char* p = reinterpret_cast<const char*>(&u);
            
            return fnc(p);
        };
    };
	*/

};

#include "pfxeReaderOBJBase.tpl"

}; // namespace

#endif // _PFXEMESHREADEROBJBASE_H_
