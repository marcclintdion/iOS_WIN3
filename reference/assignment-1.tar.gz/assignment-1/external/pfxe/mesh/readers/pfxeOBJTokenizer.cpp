#include "pfxeOBJTokenizer.h"

#include <iostream>

using namespace pfxe;

Tokenizer::Tokenizer(ifstream& _file) : file(_file)
{
    char ch;
    
    file.get(ch);
    
    setState(ch);
}

Tokenizer::~Tokenizer()
{
}

Tokenizer::TokenType
Tokenizer::getNext()
{
    switch(state)
    {
        case NUMBER   : return (last = stateNUMBER()); break;
        case SLASH    : return (last = stateSLASH()); break;
        case FACEMARK : return (last = stateFACEMARK()); break;
        case EOFSTATE : return (last = stateEOF()); break;
        default       : return (last = stateUNKNOWN()); break;
        
    }
}

Tokenizer::TokenType
Tokenizer::getToken()
{
    return last;
}

string
Tokenizer::getTokenValue()
{
    return tokenValue;
}

void 
Tokenizer::setState(char ch)
{        
    while(isspace(ch) && !file.get(ch).eof());

    
    // Verifies if we reached the end-of-file
    if(file.eof())
    {
        state = EOFSTATE;
    }
    else if(isdigit(ch))
    {
        state = NUMBER;
    }
    else if(ch == 'f')
    {
        state = FACEMARK;
    }
    else if(ch == '/')
    {
        state = SLASH;
    }
    else if(ch == '#')
    {
        stateCOMMENT();
    }
    else
    {
        state = UNKNOWN;
    }
}

Tokenizer::TokenType 
Tokenizer::stateEOF()
{
    return EOFSTATE;
}

Tokenizer::TokenType 
Tokenizer::stateSLASH()
{
    char ch;
    file.get(ch);
    
    setState(ch);
    
    return SLASH;
}

Tokenizer::TokenType 
Tokenizer::stateFACEMARK()
{
    char ch;
    file.get(ch);
    
    setState(ch);
    
    return FACEMARK;
}

Tokenizer::TokenType 
Tokenizer::stateNUMBER()
{
    char ch;
    
    tokenValue.clear();
        
    file.unget().get(ch);
    tokenValue += ch;
    while(!file.get(ch).eof() && isdigit(ch))
        tokenValue += ch;
    
    setState(ch);
    
    return NUMBER;
}

Tokenizer::TokenType 
Tokenizer::stateUNKNOWN()
{
    char ch;
    file.get(ch);
    
    setState(ch);
    
    return UNKNOWN;
}

void 
Tokenizer::stateCOMMENT()
{
    char ch;
    while(!file.get(ch).eof() && ch != '\n');
    
    file.get(ch);
    
    setState(ch);
}






SyntaticAnalysis::SyntaticAnalysis(ifstream& _file) : file(_file), tokens(file)
{
    tokens.getNext();
}

SyntaticAnalysis::~SyntaticAnalysis()
{
}

Tokenizer::TokenType
SyntaticAnalysis::readFile()
{
    Tokenizer::TokenType type = tokens.getToken(); 
    switch(type)
    {
        case Tokenizer::FACEMARK : facet(type); return Tokenizer::FACEMARK; break;
        case Tokenizer::EOFSTATE : return Tokenizer::EOFSTATE; break; 
        default : unknown(type); return Tokenizer::UNKNOWN; break;
    }
}

SyntaticAnalysis::VertexIndicesIterator 
SyntaticAnalysis::beginVertexIndices()
{
    return facesVertices.begin();
}


SyntaticAnalysis::VertexIndicesIterator 
SyntaticAnalysis::endVertexIndices()
{
    return facesVertices.end();
}

void
SyntaticAnalysis::facet(Tokenizer::TokenType& type)
{
    if(!match(Tokenizer::FACEMARK, type))
    {
        CERR(_ERROR, "\n\tExtected face mark 'f'");
    }
    
    facesVertices.clear();
    
    entry(type);
    entry(type);
    entry(type);
    
    while(type == Tokenizer::NUMBER)
        entry(type);

}

void
SyntaticAnalysis::entry(Tokenizer::TokenType& type)
{
    if(match(Tokenizer::NUMBER, type))
    {
        tUIndex idx;
        sscanf(tokenString.c_str(), "%d", &idx);        
        facesVertices.push_back(idx);
        
        
        if(type == Tokenizer::SLASH)
        {
            match(Tokenizer::SLASH, type);
            if(type == Tokenizer::NUMBER)
            {
                match(Tokenizer::NUMBER, type);
            }
            if(type == Tokenizer::SLASH)
            {
                match(Tokenizer::SLASH, type);
                if(!match(Tokenizer::NUMBER, type))
                {
                    CERR(_ERROR, "\n\tExpected a number");
                }
            }
        }
    }
    else
    {
        CERR(_ERROR, "\n\tError while reading file. Expected a number.");
    }
}


void
SyntaticAnalysis::unknown(Tokenizer::TokenType& type)
{
    match(Tokenizer::UNKNOWN, type);
}


bool
SyntaticAnalysis::match(const Tokenizer::TokenType& expected, 
    Tokenizer::TokenType& given)
{
    bool statement = given == expected;
    
    tokenString = tokens.getTokenValue();
    
    given = tokens.getNext();
    
    return statement;
}
