#ifndef PFXEPLYREADER_H_
#define PFXEPLYREADER_H_

#include <iostream>
#include <fstream>
#include <strings.h>

#include "../../defines.h"
#include "../../pfxeMeshTraits.h"

namespace pfxe
{

template <class Traits>
class ReaderPLY
{
public:
    //! Type of the mesh to be instancied.
    /*! This tells to user wich type the mesh is set to */
    typedef typename Traits::mesh Mesh;

    //! Type of the Vertex to be instancied
    typedef typename Traits::vertex Vertex;

    //! Type of the Edge to be instancied
    typedef typename Traits::edge Edge;

    //! Type of the Face to be intancied
    typedef typename Traits::face Face;

    //! Type of an array of Vertex's to be instancied
    typedef typename Traits::pfxeVertices Vertices;

    //! Type of an array of Edges to be instancied
    typedef typename Traits::pfxeEdges Edges;

    //! Type of an array of Faces to be instancied
    typedef typename Traits::pfxeFaces Faces;


public:
    //! \brief Open a PLY file
    //!
    //! This static function is responsable to load PLY files.
    //!
    //! \param mesh The mesh already allocated. Note that this function will
    //! fail case the mesh is not preallocated;
    //!
    //! \param fileName The name of the PLY file
    //!
    //! \return returns the status of the loading process: 0 means success and
	//! any other value otherwise
    static int Open(Mesh* mesh, const std::string fileName);

protected:
	static std::string element(std::ifstream& file, Mesh& mesh,
			pmath::tUIndex& sizeV, pmath::tUIndex& sizeF,
			pmath::tInt& nvProperty, pmath::tInt& sizeofVertexProperty,
			pmath::tInt& nfProperty, pmath::tInt& sizeofFaceProperty);
};

#include "pfxePLYReader.tpl"

}; // namespace

#endif /*PFXEPLYREADER_H_*/
