#ifndef PFXEMESHREADEROBJ_H_
#define PFXEMESHREADEROBJ_H_

#include "../defines.h"

#include "pfxeReaderOBJBase.h"
#include "../pfxeMeshTraits.h"

namespace pfxe
{

/*! 
 *  \brief Default mesh reader class for mesh construction
 */
class ReaderOBJ : public ReaderOBJBase<MeshTraits>
{
};

};

#endif /*PFXEMESHREADEROBJ_H_*/
