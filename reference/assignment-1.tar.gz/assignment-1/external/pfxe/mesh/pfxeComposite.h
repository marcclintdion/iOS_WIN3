#ifndef PFXECOMPOSITE_H_
#define PFXECOMPOSITE_H_

#include "defines.h"

namespace pfxe
{
    
/*!
 * \brief Base class for mesh components
 * 
 * This class is a base class for the Design Pattern Composite 
 */
class MeshComponent
{
public:
    virtual ~MeshComponent(){};
    
    //! \brief Get the size of the class in bytes
    //!
    //! This method is responsable to collect sources from all structures 
    //! involved in the hierarchical diagram. In order to do this, it is used
    //! a Design Pattern Composite. 
    //!  
    //! \return Return the size in bytes of allocated space
    virtual tUInt sizeInBytes() = 0;
};

};

#endif /*PFXECOMPOSITE_H_*/
