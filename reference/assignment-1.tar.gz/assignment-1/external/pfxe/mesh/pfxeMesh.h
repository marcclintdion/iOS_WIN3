#ifndef PFXEMESH_H_
#define PFXEMESH_H_

#include <string>

#include "pfxeMeshBase.h"
#include "pfxeMeshTraits.h"
#include "pfxeVertex.h"
#include "pfxeFace.h"

namespace pfxe
{
    
/*! \brief Default mesh class for mesh construction
 * 
 */	
class Mesh : public MeshBase<MeshTraits>
{
public:
    //! Default constructor
    Mesh(const std::string &meshName) :
    	MeshBase<MeshTraits>::MeshBase(meshName), mTexCoord(0),
    	mVerticesCoord(0)

    {
    };
    
    virtual tUInt sizeInBytes()
    {   
        return sizeof(Mesh) + MeshBase<MeshTraits>::sizeInBytes();
    }

    inline
    void allocateTextureCoordinateVector()
    {
    	if(mTexCoord) delete [] mTexCoord;
    	if(this->vertices().size())
    	{
    		mTexCoord = new float[this->vertices().size()*2];
    	}

    	mVerticesCoord = new float[3 * this->vertices().size()];
    	VertexIterator it, end;
    	it = beginVertex();
    	end = endVertex();
    	int i = 0;
    	for(; it != end; ++it, i += 3)
    	{
    		mVerticesCoord[i+0] = it->x;
    		mVerticesCoord[i+1] = it->y;
    		mVerticesCoord[i+2] = it->z;
    	}


    	mNormalCoord = new float[3 * this->vertices().size()];
    	it = beginVertex();
    	end = endVertex();
    	i = 0;
    	for(; it != end; ++it, i += 3)
    	{
    		tReal x, y, z;
    		it->getNormal(x, y, z);
    		mNormalCoord[i+0] = x;
    		mNormalCoord[i+1] = y;
    		mNormalCoord[i+2] = z;
    	}


    	mFacesIndices = new unsigned int[3 * this->faces().size()];
    	FaceIterator f, fend;
    	f = beginFace();
    	fend = endFace();
    	i = 0;
    	for(; f != fend; ++f, i+=3)
    	{
    		mFacesIndices[i+0] = f->getVertex(0).id;
    		mFacesIndices[i+1] = f->getVertex(2).id;
    		mFacesIndices[i+2] = f->getVertex(1).id;
    	}

    }

    float* mTexCoord;
    float* mVerticesCoord;
    float* mNormalCoord;
    unsigned int* mFacesIndices;
};

}; //namespace

#endif /*PFXEMESH_H_*/
