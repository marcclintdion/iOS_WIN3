#ifndef PFXEMESHMANAGER_H_
#define PFXEMESHMANAGER_H_

#include <iostream>

#include <vector>
#include <cassert>

#include "pfxeMeshInterface.h"
#include "pfxeSingleton.h"


namespace pfxe
{

//! \brief Mesh Manager to Mesh class
//!
//! The MeshManager needs to deal with a variety of types of meshes once the
//! user can specifiy its own type. So, a possibilitie to do that is to make
//! the MeshManager point to void * types. But, in this case, the MeshManager
//! could deal with anything, not only meshes. The other way is to make a
//! interface for the meshes and then makes MeshManager manager pointers to
//! that interfaces.
class MeshManager : public Singleton<MeshManager>
{
public:

    //! Type of a iterator to Meshes
    typedef std::vector<MeshInterface *>::iterator MeshIterator;

public:

    //! Trivial constructor
	MeshManager() : mSize(0)
	{
	}



    //! Trivial destructor
	~MeshManager()
	{
		for(tUIndex i = 0; i < mSize; ++i)
		{
			delete meshList[i];
		}
	}



    //! \brief This method add a new Mesh to the MeshManager.
    //!
    //! \param mesh The mesh to be added to meshList
    //!
    //! \remarks The mesh must be pre-alloocated otherwise an assertion
    //! will occur
    void addMesh(MeshInterface *mesh)
    {
        assert(mesh != 0);
        meshList.push_back(mesh);
        ++mSize;
    }


    void deleteAllMeshes()
	{
    	for(tUIndex i = 0; i < mSize; ++i)
		{
			delete meshList[i];
		}
    	meshList.clear();
	}

    void deleteMesh(MeshInterface *mesh)
    {
    	if(!mesh) return;

    	std::vector<MeshInterface *>::iterator it, end;

    	for(it = meshList.begin(), end = meshList.end(); it != end; ++it)
            if(mesh == *it)
            {
            	delete *it;
            	meshList.erase(it);
            	std::cout << "Size of Mesh List after deletion: "
					<< meshList.size() << std::endl;
            	mSize = meshList.size();
                break;
            }
    }



	//! \brief Create a new instace of empty Mesh and return it to the user.
	//!
    //! This is a template method for instantiation of an user-defined
    //! mesh class. Of course, this new type must to inherit MeshBase<> class
    //!
	//! \param meshName The name of the mesh
	//!
	//! \return Return a pointer to user-defined mesh. If the mesh cannot be allocated, 0 (null) is returned.
	//!
	//! \remarks The mesh will not be load, just allocated
	//!
	//! \remarks The user-defined type T must have a constructor with
	//! parameter std::string meshName, otherwise the createMesh will
	//! fail on compilation.
	template<class T>
	T *createMesh(const std::string &meshName)
	{
        T *mesh = new T(meshName);
        if(mesh == 0) return 0;

		meshList.push_back(dynamic_cast<MeshInterface *>(mesh));
        assert(meshList[mSize] != 0);

        std::cout << "Size of Mesh List after insertion: "
				  << meshList.size() << std::endl;

		mSize = meshList.size();

		return mesh;
	}


    //! Get the unique instancied value of MeshManager as reference
    static MeshManager &getSingleton()
    {
        assert(mInstance);
        return *mInstance;
    }



    //! Get the unique instancied value of MeshManager as pointer
    static MeshManager *getSingletonPtr()
    {
        return (mInstance);
    }



    //! \brief Get a pointer to a mesh identified by meshName
    //!
    //! \param meshName The name of the mesh we a seraching for.
    //!
    //! \return It returns a pointer to the mesh, if it exist, or 0 (null)
    //!         otherwise
    MeshInterface *getMeshByNamePtr(const std::string &meshName)
    {
        for(tUIndex i = 0; i < meshList.size(); ++i)
            if(meshName == meshList[i]->getMeshName())
                return meshList[i];
        return 0;
    }


    //! Begin of a mesh iterator
    MeshIterator beginMesh()
    {
        return meshList.begin();
    }


    //! End of a mesh iterator
    MeshIterator endMesh()
    {
        return meshList.end();
    }


    bool isAllocated(MeshInterface *mesh)
    {
    	if(!mesh)
    	{
    		CERR(_WARNING, "\n\tNo mesh allocated to perform operation.");
    		return false;
    	}

    	return true;
    }

    bool isThereFaces(MeshInterface *mesh)
    {
    	if(isAllocated(mesh) && mesh->fSize != 0)
    		return true;

    	CERR(_WARNING, "\tNo Faces in this mesh.");
    	return false;
    }

    bool isThereVertices(MeshInterface *mesh)
    {
    	if(isAllocated(mesh) && mesh->vSize != 0)
    		return true;

    	CERR(_WARNING, "\tNo Vertices in this mesh.");
    	return false;
    }

    bool isThereEdges(MeshInterface *mesh)
    {
    	if(isAllocated(mesh) && mesh->eSize != 0)
    		return true;

    	CERR(_WARNING, "\tNo Edges in this mesh.");

    	return false;
    }

protected:
    std::vector<MeshInterface *> meshList; //!< List of pointers to Mesh objects
    pfxe::tSize mSize; //!< Number of meshes on meshList
};

}; // namespace

#endif /*PFXEMESHMANAGER_H_*/
