#ifndef PFXEMESHINTERFACE_H_
#define PFXEMESHINTERFACE_H_

#include <string>

#include "defines.h"

#ifdef _MSC_VER
#define NOMINMAX
#include <windows.h>
#endif

#ifdef PFXE_SELF_RENDERING

#include <GL/gl.h>
#include <GL/glu.h>

#endif


namespace pfxe
{

//! \brief An abstract Mesh interface  class for the meshes.
//!
//!
//! This class is abstract and the another class can implement these methods to
//! create a new class.
//! This class was created for a simple reason: the MeshManager needs to deal
//! with a variety of types of meshes once the user can specify its own type.
//! So, a possibility to do that is making the MeshManager point to void*
//! types. But, in this case, the MeshManager could deal with anything, not only
//! meshes. The other way is to make a interface for the meshes and then makes
//! MeshManager manager pointers to that interfaces.
class MeshInterface
{
public:

    //! Default constructor
    MeshInterface(const std::string &meshName) :
        vSize(0), eSize(0), fSize(0), mMeshName(meshName)
    {
    }


    //! Default destructor
    virtual ~MeshInterface()
    {
    }

    //! Get the name of the mesh
    const std::string &getMeshName() const
    {
        return mMeshName;
    }


        // For Debugging purposes
#ifdef PFXE_SELF_RENDERING
    virtual void drawSolid() = 0;
    virtual void drawSmooth() = 0;
    virtual void drawWire() = 0;
    virtual void drawTetras() = 0;
    virtual void drawMeshPoints() = 0;
    virtual void drawVerticesNormal() = 0;
    virtual void drawFacesNormal() = 0;
#endif //PFXE_SELF_RENDERING


    tSize vSize; //!< Number of vertices on mesh
    tSize eSize; //!< Number of edges on mesh
    tSize fSize; //!< Number of faces on mesh

protected:

    //! \brief The mesh name.
    //! \remarks Every mesh must have a name. If this name is not unique
    //! then when a search by name is requested, the first occurance of the
    //! name will be reported
    std::string mMeshName;
};

};

#endif /*PFXEMESHINTERFACE_H_*/
