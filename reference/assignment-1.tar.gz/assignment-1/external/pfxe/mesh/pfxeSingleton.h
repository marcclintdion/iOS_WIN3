#ifndef PFXESINGLETON_H_
#define PFXESINGLETON_H_

#include <cassert>


namespace pfxe
{    
template <class T>

//! \brief Singleton class.
class Singleton
{
protected:
    static T *mInstance; //!< The unique instancied object

public:
    Singleton()
    {
        assert(!mInstance);        
        mInstance = static_cast<T *>(this);
    }
    virtual ~Singleton()
    {
    }
    
    //! Gets a pointer to the unique instacied object
    static T *getSingletonPtr()
    {
        return mInstance; 
    }
    
    //! Gets a reference to the unique instacied object
    static T &getSingleton()    
    {
        return *mInstance; 
    }
    
};

template <class T> 
T*
Singleton<T>::mInstance = 0;

};

#endif /*PFXESINGLETON_H_*/
