#ifndef PFXE_DEFINES_H_
#define PFXE_DEFINES_H_

/*!
 *  \namespace pfxe
 *  \brief Namespace for mesh functions and objects
 */
namespace global
{

/*! \typedef tInt
 *  \brief Default Integer type
 */
typedef int tInt;


/*! \typedef tUInt
 *  \brief Default Integer type
 */
typedef unsigned /*long*/ int tUInt;

/*! \typedef tIndex
 *  \brief Default Index type
 */
typedef int tIndex;

/*! \typedef tUIndex
 *  \brief Default Usigned Index type
 */
typedef unsigned int tUIndex;

/*! \typedef tSize
 *  \brief Default Size type
 */
typedef unsigned int tSize;

/*! \typedef tReal
 *  \brief Default Real type
 */
typedef double tReal;


#define _WARNING       0
#define _WARNING_ONCE  2
#define _ERROR         1
#define _NONE         -1
#define _SHOW_ONCE    -2

#define CERR(type, message)                                    \
        {                                                      \
            static bool warning_once = true;                   \
            static bool show_once = true;                      \
            if(type == _WARNING)                               \
                std::cerr << "WARNING: file " << __FILE__      \
                     << " line " << __LINE__ << ": "           \
                     << message << std::endl;                  \
            else if(type == _WARNING_ONCE)                     \
            {                                                  \
                if(warning_once)                               \
                std::cerr << "WARNING ONCE: file " << __FILE__ \
                     << " line " << __LINE__ << ": "           \
                     << message << std::endl;                  \
                warning_once = false;                          \
            }                                                  \
            else if(type == _ERROR)                            \
                std::cerr << "ERROR: file " << __FILE__        \
                     << " line " << __LINE__ << ": "           \
                     << message << std::endl;                  \
            else if(type == _SHOW_ONCE)                        \
            {                                                  \
                if(show_once)                                  \
                std::cerr << "OUTPUT ONCE: file " << __FILE__  \
                     << " line " << __LINE__ << ": "           \
                     << message << std::endl;                  \
                show_once = false;                             \
            }                                                  \
            else                                               \
                std::cerr << "OUTPUT: file " << __FILE__       \
                     << " line " << __LINE__ << ": "           \
                     << message << std::endl;                  \
        }

#define COUT(type, message)                                    \
        {                                                      \
            static bool warning_once = true;                   \
            static bool show_once = true;                      \
            if(type == _WARNING)                               \
                std::cout << "WARNING: file " << __FILE__      \
                     << " line " << __LINE__ << ": "           \
                     << message << std::endl;                  \
            else if(type == _WARNING_ONCE)                     \
            {                                                  \
                if(warning_once)                               \
                std::cout << "WARNING ONCE: file " << __FILE__ \
                     << " line " << __LINE__ << ": "           \
                     << message << std::endl;                  \
                warning_once = false;                          \
            }                                                  \
            else if(type == _ERROR)                            \
                std::cout << "ERROR: file " << __FILE__        \
                     << " line " << __LINE__ << ": "           \
                     << message << std::endl;                  \
            else if(type == _SHOW_ONCE)                        \
            {                                                  \
                if(show_once)                                  \
                std::cout << "OUTPUT ONCE: file " << __FILE__  \
                     << " line " << __LINE__ << ": "           \
                     << message << std::endl;                  \
                show_once = false;                             \
            }                                                  \
            else                                               \
                std::cout << "OUTPUT: file " << __FILE__       \
                     << " line " << __LINE__ << ": "           \
                     << message << std::endl;                  \
        }


}; //namespace


//! \brief Namespace for mathematical functions and objects
//!
//! \todo The name of this namespace must be modified
namespace pmath
{


//! Integer type
typedef global::tInt tInt;


//! Unsigned integer type
typedef global::tUInt tUInt;


//! Index type
typedef global::tIndex tIndex;


//! Unsigned index type
typedef global::tUIndex tUIndex;


//! Unsigned size type
typedef global::tSize tSize;


//! Real type
typedef global::tReal tReal;

};



/*!
 *  \namespace pfxe
 *  \brief Namespace for mesh functions and objects
 */
namespace pfxe
{

/*! \typedef tInt
 *  \brief Default Integer type
 */
typedef global::tInt tInt;


/*! \typedef tUInt
 *  \brief Default Integer type
 */
typedef global::tUInt tUInt;

/*! \typedef tIndex
 *  \brief Default Index type
 */
typedef global::tIndex tIndex;

/*! \typedef tUIndex
 *  \brief Default Usigned Index type
 */
typedef global::tUIndex tUIndex;

/*! \typedef tSize
 *  \brief Default Size type
 */
typedef global::tSize tSize;

/*! \typedef tReal
 *  \brief Default Real type
 */
typedef global::tReal tReal;

#define _WARNING       0
#define _WARNING_ONCE  2
#define _ERROR         1
#define _NONE         -1
#define _SHOW_ONCE    -2

#define CERR(type, message)                                    \
        {                                                      \
            static bool warning_once = true;                   \
            static bool show_once = true;                      \
            if(type == _WARNING)                               \
                std::cerr << "WARNING: file " << __FILE__      \
                     << " line " << __LINE__ << ": "           \
                     << message << std::endl;                  \
            else if(type == _WARNING_ONCE)                     \
            {                                                  \
                if(warning_once)                               \
                std::cerr << "WARNING ONCE: file " << __FILE__ \
                     << " line " << __LINE__ << ": "           \
                     << message << std::endl;                  \
                warning_once = false;                          \
            }                                                  \
            else if(type == _ERROR)                            \
                std::cerr << "ERROR: file " << __FILE__        \
                     << " line " << __LINE__ << ": "           \
                     << message << std::endl;                  \
            else if(type == _SHOW_ONCE)                        \
            {                                                  \
                if(show_once)                                  \
                std::cerr << "OUTPUT ONCE: file " << __FILE__  \
                     << " line " << __LINE__ << ": "           \
                     << message << std::endl;                  \
                show_once = false;                             \
            }                                                  \
            else                                               \
                std::cerr << "OUTPUT: file " << __FILE__       \
                     << " line " << __LINE__ << ": "           \
                     << message << std::endl;                  \
        }

#define COUT(type, message)                                    \
        {                                                      \
            static bool warning_once = true;                   \
            static bool show_once = true;                      \
            if(type == _WARNING)                               \
                std::cout << "WARNING: file " << __FILE__      \
                     << " line " << __LINE__ << ": "           \
                     << message << std::endl;                  \
            else if(type == _WARNING_ONCE)                     \
            {                                                  \
                if(warning_once)                               \
                std::cout << "WARNING ONCE: file " << __FILE__ \
                     << " line " << __LINE__ << ": "           \
                     << message << std::endl;                  \
                warning_once = false;                          \
            }                                                  \
            else if(type == _ERROR)                            \
                std::cout << "ERROR: file " << __FILE__        \
                     << " line " << __LINE__ << ": "           \
                     << message << std::endl;                  \
            else if(type == _SHOW_ONCE)                        \
            {                                                  \
                if(show_once)                                  \
                std::cout << "OUTPUT ONCE: file " << __FILE__  \
                     << " line " << __LINE__ << ": "           \
                     << message << std::endl;                  \
                show_once = false;                             \
            }                                                  \
            else                                               \
                std::cout << "OUTPUT: file " << __FILE__       \
                     << " line " << __LINE__ << ": "           \
                     << message << std::endl;                  \
        }


}; //namespace

#endif /*PFXE_DEFINES_H_*/
