/*
 * main.cpp
 *
 *  Created on: Sep 10, 2009
 *      Author: etiene
 *
 *  This file is part of assignment-1.
 *
 *  assignment-1 is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  assignment-1 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with assignment-1.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <iostream>
#include <algorithm>
#include <map>
#include <string>

#include <pfxe/mesh/pfxeMeshManager.h>
#include <pfxe/mesh/readers/ply/pfxePLYReader.h>
#include <pfxe/mesh/pfxeMesh.h>
#include <pfxe/mesh/pfxeFace.h>
#include <pfxe/mesh/pfxeEdge.h>
#include <pfxe/mesh/pfxeTetra.h>
#include <pfxe/mesh/pfxeVertex.h>
#include <pfxe/mesh/pfxeMeshTraits.h>

#include <GL/glui.h>
#include <GL/glut.h>

#include "camera.hpp"
#include "material.hpp"
#include "textures.hpp"
#include "texture2d.hpp"
#include "lighting.hpp"
#include "objects.hpp"

// GLUI

// the user id's that we can use to identify which control
// caused the callback to be called
#define CB_DEPTH_BUFFER 0
#define CB_ACTION_BUTTON 1
#define CB_RESET 2
#define CB_PLAY 3
#define CB_STOP 4
#define CB_CHANGE_SPEED 5
#define CB_UPDATE_CUBE_MAP 6


GLUI* glui;
GLUI_Rollout* texture_rollout;
GLUI_Rollout* lightmap_rollout;
GLUI_Rollout* cubemap_rollout;
GLUI_Translation* lightmap_xz_trans;
GLUI_RadioGroup* object_type_radio;
GLUI_Spinner *spin_s;
GLUI_Spinner* lightmap_size;
GLUI_StaticText *spin_alpha;


// State variables

bool play_animation = false;
int live_object_type = 0;
float live_object_xz_trans[2];
GLuint mainWindow;
float lambda = 1.0;
GLfloat speed  = 1E-7;
float scale = 1.0;
int enable_lightmap = 1;
int debug = 0;
bool takeAScreenShot = true;
int continuousShots = 0;

GLfloat currentModelview[16];
GLfloat currentTexture[16];
GLfloat rotX = 0.0;
GLfloat rotY = 0.0;
GLenum mode = GL_MODULATE;

#ifndef M_PI
#define M_PI            (3.14159265358979f)
#endif
#define DTOR            (M_PI/180.0)
#define RTOD            (180.0/M_PI)
#define ZTRANS 4.0F

GLfloat pos_light00[] 	= {1.5, 1.5, 1.5, 0.0};
GLfloat diffuse_light00[] = {1.0, 1.0, 1.0, 1.0};
GLfloat pos_light01[] 	= {-1.5, -1.5, -1.5, 0.0};
GLfloat diffuse_light01[] = {1.0, 1.0, 1.0, 1.0};

void glui_cb(int control)
{

	switch(control)
	{
	case CB_PLAY: play_animation = true;
				  break;
	case CB_STOP: play_animation = false;
				  break;
	case CB_RESET: play_animation = false;
				  lambda = 1.0;
				  spin_alpha->set_float_val(lambda);
				  spin_alpha->redraw();
				  break;
	case CB_CHANGE_SPEED:
				  speed = spin_s->get_float_val();
				  break;
	case CB_UPDATE_CUBE_MAP:
				  takeAScreenShot = true;
				  break;

	}

	glutPostRedisplay();
}

///////////////////



GLenum getMode(int i)
{
	if(i == 0)
		return GL_MODULATE;
	else if(i == 1)
		return GL_REPLACE;
	else if(i == 2)
		return GL_BLEND;

	return GL_DECAL;
}



#define WINDOW_NAME "Assignment 1 - Interactive Computer Graphics"
#define POS_X		100
#define POS_Y		100
#define WIDTH		1000
#define HEIGHT 		1000

ogl::Camera& cam = ogl::Camera::getSingleton();
ogl::Lighting& lighting = ogl::Lighting::getSingleton();
ogl::Textures& textures = ogl::Textures::getSingleton();
std::map<std::string, ogl::Material> obj2mat;

float angle = 0.0;;




unsigned int* colorBuffer;


void drawScene(bool update);

void printMatrix(GLfloat* m)
{
	for(int i = 0; i < 16; ++i)
	{
		if(i % 4 == 0)
			std::cout << std::endl;
		std::cout << m[i] << " ";
	}
}

void redraw()
{
	int h = HEIGHT, w = WIDTH;
	GLenum data_size = GL_UNSIGNED_INT;


	if(takeAScreenShot or continuousShots)
	{
		glEnable(GL_DEPTH_TEST);

		ogl::TextureCubeMapping cubeTexture;

		cam.mFovy = 90.0;
		cam.mEye[0] = 0.0;
		cam.mEye[1] = 0.0;
		cam.mEye[2] = 0.0;

		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		cam.setPerspectiveProjection();

		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		cam.mFocus[0] = -1.0;
		cam.mFocus[1] =  0.0;
		cam.mFocus[2] =  0.0;
		cam.mUp[0] =  0.0;
		cam.mUp[1] =  -1.0;
		cam.mUp[2] =  0.0;
		cam.takeALook();
		drawScene(false);
		glReadBuffer(GL_BACK);
		glReadPixels(0, 0, w, h, GL_RGBA, data_size, colorBuffer);
		cubeTexture.setCubeTex(GL_TEXTURE_CUBE_MAP_NEGATIVE_X,
							   colorBuffer, w, h, data_size);

//		glDrawPixels(w, h, GL_RGBA, data_size, colorBuffer);
//		glutSwapBuffers();
//		return;

		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		cam.setPerspectiveProjection();

		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		cam.mFocus[0] = +1.0;
		cam.mFocus[1] =  0.0;
		cam.mFocus[2] =  0.0;
		cam.mUp[0] =  0.0;
		cam.mUp[1] =  -1.0;
		cam.mUp[2] =  0.0;
		cam.takeALook();
		drawScene(false);
		glReadBuffer(GL_BACK);
		glReadPixels(0, 0, w, h, GL_RGBA, data_size, colorBuffer);
		cubeTexture.setCubeTex(GL_TEXTURE_CUBE_MAP_POSITIVE_X,
							   colorBuffer, w, h, data_size);


		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		cam.mFocus[0] =   0.0;
		cam.mFocus[1] =   0.0;
		cam.mFocus[2] =  -1.0;
		cam.mUp[0] =  0.0;
		cam.mUp[1] =  -1.0;
		cam.mUp[2] =  0.0;
		cam.takeALook();
		drawScene(false);
		glReadBuffer(GL_BACK);
		glReadPixels(0, 0, w, h, GL_RGBA, data_size, colorBuffer);
		cubeTexture.setCubeTex(GL_TEXTURE_CUBE_MAP_NEGATIVE_Z,
							   colorBuffer, w, h, data_size);

//		glDrawPixels(w, h, GL_RGBA, data_size, colorBuffer);
//		glutSwapBuffers();
//		return;


		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		cam.setPerspectiveProjection();

		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		cam.mFocus[0] =  0.0;
		cam.mFocus[1] =  0.0;
		cam.mFocus[2] = +1.0;
		cam.mUp[0] =  0.0;
		cam.mUp[1] = -1.0;
		cam.mUp[2] =  0.0;
		cam.takeALook();
		drawScene(false);
		glReadBuffer(GL_BACK);
		glReadPixels(0, 0, w, h, GL_RGBA, data_size, colorBuffer);
		cubeTexture.setCubeTex(GL_TEXTURE_CUBE_MAP_POSITIVE_Z,
							   colorBuffer, w, h, data_size);




		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		cam.setPerspectiveProjection();

		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		cam.mFocus[0] =   0.0;
		cam.mFocus[1] =  -1.0;
		cam.mFocus[2] =   0.0;
		cam.mUp[0] =  0.0;
		cam.mUp[1] =  0.0;
		cam.mUp[2] =  -1.0;
		cam.takeALook();
		drawScene(false);
		glReadBuffer(GL_BACK);
		glReadPixels(0, 0, w, h, GL_RGBA, data_size, colorBuffer);
		cubeTexture.setCubeTex(GL_TEXTURE_CUBE_MAP_NEGATIVE_Y,
							   colorBuffer, w, h, data_size);

//		glDrawPixels(w, h, GL_RGBA, data_size, colorBuffer);
//		glutSwapBuffers();
//		return;

		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		cam.setPerspectiveProjection();

		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		cam.mFocus[0] =  0.0;
		cam.mFocus[1] =  1.0;
		cam.mFocus[2] =  0.0;
		cam.mUp[0] =  0.0;
		cam.mUp[1] =  0.0;
		cam.mUp[2] =  1.0;
		cam.takeALook();
		drawScene(false);
		glReadBuffer(GL_BACK);
		glReadPixels(0, 0, w, h, GL_RGBA, data_size, colorBuffer);
		cubeTexture.setCubeTex(GL_TEXTURE_CUBE_MAP_POSITIVE_Y,
							   colorBuffer, w, h, data_size);

//		glDrawPixels(w, h, GL_RGBA, data_size, colorBuffer);
//		glutSwapBuffers();
//		return;

//		cubeTexture.setCubeTex("./resources/xn.rgb", "./resources/yn.rgb",
//							   "./resources/zn.rgb", "./resources/xp.rgb",
//							   "./resources/yp.rgb", "./resources/zp.rgb");


		glEnable(GL_TEXTURE_CUBE_MAP);

		glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_REFLECTION_MAP);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_REFLECTION_MAP);
		glTexGeni(GL_R, GL_TEXTURE_GEN_MODE, GL_REFLECTION_MAP);
//		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_NORMAL_MAP);
//		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_NORMAL_MAP);
//		glTexGeni(GL_R, GL_TEXTURE_GEN_MODE, GL_NORMAL_MAP);

		glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP);
		glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP);

		glDisable(GL_TEXTURE_CUBE_MAP);

		takeAScreenShot = false;
	}


	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	cam.mFovy = 45;
	cam.setPerspectiveProjection();

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	cam.mEye[0] = 0.0;
	cam.mEye[1] = 0.0;
	cam.mEye[2] = 8.0;
	cam.mFocus[0] = 0.0;
	cam.mFocus[1] = 0.0;
	cam.mFocus[2] = 0.0;
	cam.mUp[0] =  0.0;
	cam.mUp[1] =  1.0;
	cam.mUp[2] =  0.0;
	cam.takeALook();

	drawScene(true);

	glutSwapBuffers();
}



void drawScene(bool updateModelViewMatrix)
{
	float teapot_size = 0.7;
	float teapot_trans = 1.5;


	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


	glEnable(GL_NORMALIZE);

	glMatrixMode(GL_MODELVIEW);

	GLfloat tmp[16];

	glPushMatrix();
		glLoadIdentity();
		glRotatef(rotX, 1.0, 0.0, 0.0);
		glRotatef(rotY, 0.0, 1.0, 0.0);
		glMultMatrixf(currentModelview);
		if(updateModelViewMatrix)
			glGetFloatv(GL_MODELVIEW_MATRIX, currentModelview);
		glGetFloatv(GL_MODELVIEW_MATRIX, tmp);
	glPopMatrix();

	glPushMatrix();
		glMultMatrixf(tmp);

		lighting.setLightPosition(0, pos_light00);
		lighting.setLightPosition(1, pos_light01);

		obj2mat["teapot-01"].setState();
		glPushMatrix();
			glTranslatef(teapot_trans, 0.0, -teapot_trans);
			glutSolidTeapot(teapot_size);
		glPopMatrix();

		obj2mat["teapot-02"].setState();
		glPushMatrix();
			glTranslatef(-teapot_trans, 0.0, -teapot_trans);
			glutSolidTeapot(teapot_size);
		glPopMatrix();

		obj2mat["teapot-00"].setState();
		glPushMatrix();
			glTranslatef(0.0, 0.0, -1.5 * teapot_trans);
			glutSolidTeapot(teapot_size);
		glPopMatrix();

		obj2mat["cube"].setState();


		glVertexPointer(3, GL_FLOAT, 0, ogl::sphere->mVerticesCoord);
		glNormalPointer(GL_FLOAT, 0, ogl::sphere->mNormalCoord);

		// Earth Texture
		{
			glActiveTexture(GL_TEXTURE0);
			glClientActiveTexture(GL_TEXTURE0);
			glEnable(GL_TEXTURE_2D);
			glTexCoordPointer(2, GL_FLOAT, 0, ogl::sphere->mTexCoord);
			glEnableClientState (GL_TEXTURE_COORD_ARRAY);
			float color4[] = {0.0, 0.0, 0.0, lambda};
			glTexEnvfv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, color4);
			textures.bindTexture(2, GL_TEXTURE_2D);
			glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,
					getMode(live_object_type));
			glTexEnvf(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_INTERPOLATE);
			glTexEnvf(GL_TEXTURE_ENV, GL_SRC0_RGB, GL_TEXTURE);
			glTexEnvf(GL_TEXTURE_ENV, GL_OPERAND0_RGB, GL_SRC_COLOR);
			glTexEnvf(GL_TEXTURE_ENV, GL_SRC1_RGB, GL_PREVIOUS);
			glTexEnvf(GL_TEXTURE_ENV, GL_OPERAND1_RGB, GL_SRC_COLOR);
			glTexEnvf(GL_TEXTURE_ENV, GL_SRC2_RGB, GL_CONSTANT);
			glTexEnvf(GL_TEXTURE_ENV, GL_OPERAND1_RGB, GL_SRC_ALPHA);
		}

		// Me Texture
		{
			glActiveTexture(GL_TEXTURE1);
			glClientActiveTexture(GL_TEXTURE1);
			glEnable(GL_TEXTURE_2D);
			glTexCoordPointer(2, GL_FLOAT, 0, ogl::sphere->mTexCoord);
			glEnableClientState (GL_TEXTURE_COORD_ARRAY);
			float colorMe[] = {0.0, 0.0, 0.0, 1.0-lambda};
			glTexEnvfv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, colorMe);
			textures.bindTexture(3, GL_TEXTURE_2D);
			glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
			glTexEnvf(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_INTERPOLATE);
		}

	    glPushMatrix();
			glRotatef(90, 1.0, 0.0, 0.0);
			glTranslatef(1.2, 1.2, 1.2);
			glDrawElements(GL_TRIANGLES, ogl::sphere->faces().size() * 3,
							GL_UNSIGNED_INT, ogl::sphere->mFacesIndices);
		glPopMatrix();

		glActiveTexture(GL_TEXTURE0);
		glDisable(GL_TEXTURE_2D);
		glActiveTexture(GL_TEXTURE1);
		glDisable(GL_TEXTURE_2D);
		glActiveTexture(GL_TEXTURE0);
		glClientActiveTexture(GL_TEXTURE0);


		// Lightmap texture
		if(enable_lightmap)
		{
			ogl::reset(ogl::wall_texture_bottoms, ogl::wall_texture_bottoms+16,
				  ogl::wall_texture_bottom);
			glActiveTexture(GL_TEXTURE0);
			glClientActiveTexture(GL_TEXTURE0);
			glEnableClientState (GL_TEXTURE_COORD_ARRAY);
			textures.enableTexture(GL_TEXTURE_2D);
			glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
			glVertexPointer(3, GL_FLOAT, 0, ogl::wall_vertices);
			glNormalPointer(GL_FLOAT, 0, ogl::wall_normals);
			ogl::translate(ogl::wall_texture_bottoms,
				ogl::wall_texture_bottoms+16,
				live_object_xz_trans[0], live_object_xz_trans[1]);
			ogl::scale(ogl::wall_texture_bottoms, ogl::wall_texture_bottoms+16,
					scale);
			glTexCoordPointer(2, GL_FLOAT, 0, ogl::wall_texture_bottoms);
			textures.bindTexture(4, GL_TEXTURE_2D);
		}

		// Floor texture
		{
			if(enable_lightmap)
			{
				glActiveTexture(GL_TEXTURE1);
				glClientActiveTexture(GL_TEXTURE1);
			}
			glEnableClientState (GL_TEXTURE_COORD_ARRAY);
			textures.enableTexture(GL_TEXTURE_2D);
			glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
			glVertexPointer(3, GL_FLOAT, 0, ogl::wall_vertices);
			glNormalPointer(GL_FLOAT, 0, ogl::wall_normals);
			glTexCoordPointer(2, GL_FLOAT, 0, ogl::wall_texture_bottom);
			textures.bindTexture(0, GL_TEXTURE_2D);
		}
		glPushMatrix();
			glScalef(6.0, 6.0, 6.0);
			glTranslatef(-0.5, -0.5, -0.5);
			glDrawElements(GL_QUADS, 4, GL_UNSIGNED_BYTE, ogl::bottom_face);
		glPopMatrix();


		glActiveTexture(GL_TEXTURE0);
		glDisable(GL_TEXTURE_2D);
		glActiveTexture(GL_TEXTURE1);
		glDisable(GL_TEXTURE_2D);
		glActiveTexture(GL_TEXTURE0);
		glClientActiveTexture(GL_TEXTURE0);



		// Walls texture
		{
			textures.enableTexture(GL_TEXTURE_2D);
			textures.bindTexture(1, GL_TEXTURE_2D);
			glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		}
		glPushMatrix();
			glScalef(6.0, 6.0, 6.0);
			glTranslatef(-0.5, -0.5, -0.5);
			if(debug) textures.bindTexture(5, GL_TEXTURE_2D);
			glTexCoordPointer(2, GL_FLOAT, 0, ogl::wall_texture_left);
			glDrawElements(GL_QUADS, 4, GL_UNSIGNED_BYTE, ogl::left_face);
			if(debug) textures.bindTexture(6, GL_TEXTURE_2D);
			glTexCoordPointer(2, GL_FLOAT, 0, ogl::wall_texture_right);
			glDrawElements(GL_QUADS, 4, GL_UNSIGNED_BYTE, ogl::right_face);
			if(debug) textures.bindTexture(7, GL_TEXTURE_2D);
			glTexCoordPointer(2, GL_FLOAT, 0, ogl::wall_texture_front);
			glDrawElements(GL_QUADS, 4, GL_UNSIGNED_BYTE, ogl::front_face);
			if(debug) textures.bindTexture(8, GL_TEXTURE_2D);
			glTexCoordPointer(2, GL_FLOAT, 0, ogl::wall_texture_back);
			glDrawElements(GL_QUADS, 4, GL_UNSIGNED_BYTE, ogl::back_face);
			if(debug) textures.bindTexture(9, GL_TEXTURE_2D);
			glTexCoordPointer(2, GL_FLOAT, 0, ogl::wall_texture_upper);
			glDrawElements(GL_QUADS, 4, GL_UNSIGNED_BYTE, ogl::upper_face);
		glPopMatrix();
		textures.disableTexture(GL_TEXTURE_2D);


//		// Cube Map
		obj2mat["white"].setState();
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		glEnable(GL_TEXTURE_GEN_R);
		glEnable(GL_TEXTURE_CUBE_MAP);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
		glCullFace(GL_BACK);
		glPushMatrix();
		{
			glutSolidSphere(1.0, 50, 50);
//			glutSolidTeapot(1.0);
		}
		glPopMatrix();
		glCullFace(GL_FRONT);
		glDisable(GL_TEXTURE_CUBE_MAP);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
		glDisable(GL_TEXTURE_GEN_R);

//		glPopMatrix();


		// Drawing light source
//		lighting.disableLighting();
//		glColor3f(1.0, 1.0, 1.0);
//		glPointSize(5);
//		lighting.drawAllLightSources();
//		lighting.enableLighting();
//
//
		glPopMatrix();
//
		if(updateModelViewMatrix)
			rotX = rotY = 0.0;
}


void reshape(GLsizei w, GLsizei h)
{
	if(h == 0) h = 1;
	glViewport(0, 0, w, h);

	cam.mAspectRatio = (GLdouble) w / (GLdouble) h;
}

void initScene()
{
	glClearColor(0.0, 0.0, 0.0, 1.0);
	glEnable(GL_DEPTH_TEST);

	// Material parameters
	GLfloat diffuse_mat00[] = {1.0, 0.0, 0.0, 1.0};
	GLfloat diffuse_mat01[] = {0.0, 1.0, 0.0, 1.0};
	GLfloat diffuse_mat02[] = {0.0, 0.0, 1.0, 1.0};
	GLfloat diffuse_mat03[] = {1.0, 0.5, 0.5, 1.0};
	GLfloat diffuse_mat04[] = {1.0, 1.0, 1.0, 1.0};

	obj2mat["teapot-00"] = ogl::Material();
	obj2mat["teapot-00"].setDiffuseReflectance(diffuse_mat00);

	obj2mat["teapot-01"] = ogl::Material();
	obj2mat["teapot-01"].setDiffuseReflectance(diffuse_mat01);

	obj2mat["teapot-02"] = ogl::Material();
	obj2mat["teapot-02"].setDiffuseReflectance(diffuse_mat02);

	obj2mat["cube"] = ogl::Material();
	obj2mat["cube"].setDiffuseReflectance(diffuse_mat03);

	obj2mat["white"] = ogl::Material();
	obj2mat["white"].setDiffuseReflectance(diffuse_mat04);

	lighting.enableLight(0);
	lighting.setLightPosition(0, pos_light00);
	lighting.setLightDiffuse(0, diffuse_light00);

	lighting.enableLight(1);
	lighting.setLightPosition(1, pos_light01);
	lighting.setLightDiffuse(1, diffuse_light01);

	lighting.setShadeModel(GL_SMOOTH);
	lighting.enableLighting();
	lighting.enableNormalize();

	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_NORMAL_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);

	glFrontFace(GL_CCW);
	glCullFace(GL_FRONT);
	glEnable(GL_CULL_FACE);


	//
	// Setting up textures
	//
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glPixelStorei(GL_PACK_ALIGNMENT, 1);
	textures.generateTexturesNames(11);


	// Texture 0
	textures.bindTexture(0, GL_TEXTURE_2D);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER,
								  GL_NEAREST);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
								  GL_NEAREST_MIPMAP_NEAREST);
	textures.set2DMipmapTexture("./resources/NewPlank-%d.rgb", 10, GL_RGBA, 0,
								 GL_RGBA, GL_UNSIGNED_BYTE);


	// Texture 1
	textures.bindTexture(1, GL_TEXTURE_2D);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER,
								  GL_LINEAR);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
								  GL_NEAREST_MIPMAP_NEAREST);
	textures.set2DMipmapTexture("./resources/Brick-%d.rgb", 9, GL_RGBA, 0,
								GL_RGBA, GL_UNSIGNED_BYTE);


	// Texture 2 - Earth
	textures.bindTexture(2, GL_TEXTURE_2D);
	textures.loadRGBTexture("./resources/earth.rgb");
	textures.set2DTexture(GL_RGBA, 0, GL_RGBA, GL_UNSIGNED_BYTE);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER,
								  GL_LINEAR);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
								  GL_LINEAR);

	// Texture 2 - Me
	textures.bindTexture(3, GL_TEXTURE_2D);
	textures.loadRGBTexture("./resources/photo.rgb");
	textures.set2DTexture(GL_RGBA, 0, GL_RGBA, GL_UNSIGNED_BYTE);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER,
								  GL_LINEAR);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
								  GL_LINEAR);


	// Texture 2 - Lightmap
	textures.bindTexture(4, GL_TEXTURE_2D);
	textures.loadRGBTexture("./resources/lightmap.rgb");
	textures.set2DTexture(GL_RGBA, 0, GL_RGBA, GL_UNSIGNED_BYTE);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER,
								  GL_LINEAR);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
								  GL_LINEAR);
	float borderColor[] = {0.0, 0.0, 0.0, 1.0};
	glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, borderColor);



	// Texture 2 - Earth
	textures.bindTexture(5, GL_TEXTURE_2D);
	textures.loadRGBTexture("./resources/1.rgb");
	textures.set2DTexture(GL_RGBA, 0, GL_RGBA, GL_UNSIGNED_BYTE);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER,
								  GL_LINEAR);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
								  GL_LINEAR);


	textures.bindTexture(6, GL_TEXTURE_2D);
	textures.loadRGBTexture("./resources/2.rgb");
	textures.set2DTexture(GL_RGBA, 0, GL_RGBA, GL_UNSIGNED_BYTE);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER,
								  GL_LINEAR);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
								  GL_LINEAR);



	textures.bindTexture(7, GL_TEXTURE_2D);
	textures.loadRGBTexture("./resources/3.rgb");
	textures.set2DTexture(GL_RGBA, 0, GL_RGBA, GL_UNSIGNED_BYTE);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER,
								  GL_LINEAR);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
								  GL_LINEAR);


	textures.bindTexture(8, GL_TEXTURE_2D);
	textures.loadRGBTexture("./resources/4.rgb");
	textures.set2DTexture(GL_RGBA, 0, GL_RGBA, GL_UNSIGNED_BYTE);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER,
								  GL_LINEAR);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
								  GL_LINEAR);


	textures.bindTexture(9, GL_TEXTURE_2D);
	textures.loadRGBTexture("./resources/5.rgb");
	textures.set2DTexture(GL_RGBA, 0, GL_RGBA, GL_UNSIGNED_BYTE);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER,
								  GL_LINEAR);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
								  GL_LINEAR);


	textures.bindTexture(10, GL_TEXTURE_2D);
	textures.loadRGBTexture("./resources/6.rgb");
	textures.set2DTexture(GL_RGBA, 0, GL_RGBA, GL_UNSIGNED_BYTE);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER,
								  GL_LINEAR);
	textures.setTexturesParameter(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
								  GL_LINEAR);



	//
	// Setting up Meshes
	//
	ogl::sphere = pfxe::MeshManager::getSingleton().
			createMesh<pfxe::Mesh>("sphere");

	pfxe::ReaderPLY<pfxe::MeshTraits>::
		Open(ogl::sphere, "./resources/sphere.ply");

	ogl::sphere->allocateTextureCoordinateVector();
	pfxe::Mesh::VertexIterator it, end;
	it  = ogl::sphere->beginVertex();
	end = ogl::sphere->endVertex();
	int i = 0;
	float radius = 1.0;
	for(; it != end; ++it, i += 2)
	{
		ogl::sphere->mTexCoord[i+0] = atan2(it->x, it->y) / ogl::TWO_PI + 0.5;

		double angle = it->z / radius;
		if(angle > 1.0) angle = 1.0;
		if(angle < -1.0) angle = -1.0;
		ogl::sphere->mTexCoord[i+1] = 1.0 * (acos(angle) / ogl::PI) ;


		assert(!std::isnan(ogl::sphere->mTexCoord[i+0]));
		assert(!std::isnan(ogl::sphere->mTexCoord[i+1]));
	}

	glClearColor(0.0, 0.0, 0.0, 1.0);


	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	cam.setPerspectiveProjection();


	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glGetFloatv(GL_MODELVIEW_MATRIX, currentModelview);
	cam.takeALook();

	glHint(GL_POLYGON_SMOOTH_HINT, GL_NICEST);



}

void keyboard(unsigned char key, int x, int y)
{
	rotX = rotY = 0;
	switch(key)
	{
	case 'q':
	case 'Q':
			  pfxe::MeshManager::getSingleton().deleteAllMeshes();
			  delete colorBuffer;
			  exit(1);
			  break;
	case '+': lambda += speed;
			  lambda = std::min(lambda, 1.0f);
			  break;
	case '-': lambda -= speed;
			  lambda = std::max(lambda, 0.0f);
			  break;
	case '<': speed -= 0.1;
			  speed = std::max(speed, 0.0f);
			  break;
	case '>': speed += 0.1;
			  break;
	case 'a': scale += 0.1;
			  break;
	case 's': scale -= 0.1;
			  break;
	case 'd': live_object_xz_trans[0] += speed;
			  break;
	case 'g': live_object_xz_trans[0] -= speed;
			  break;
	case 'r': live_object_xz_trans[1] += speed;
			  break;
	case 'f': live_object_xz_trans[1] -= speed;
			  break;
	case '1': mode = GL_MODULATE;
			 break;
	case '2': mode = GL_REPLACE;
			 break;
	case '3': mode = GL_BLEND;
			 break;
	case '4': mode = GL_DECAL;
			 break;
	case 'T' :
	case 't' : debug = !debug;
			 break;
	case 'w' : takeAScreenShot = true;
			 break;
	case 'e' : continuousShots = !continuousShots;
			break;
	default: break;
	};

	 glutPostRedisplay();
}

static int lastX = 0, lastY = 0;
void mouseMotion(int x, int y)
{
	if(lastX == 0)
		lastX = x;
	if(lastY == 0)
		lastY = y;
	rotY = 0.3 * ((GLfloat)x - (GLfloat)lastX);
	rotX = 0.3 * ((GLfloat)y - (GLfloat)lastY);
	lastX = x;
	lastY = y;

	 glutPostRedisplay();
}

void mouse(int button, int state, int x, int y)
{
	if(button == GLUT_MIDDLE_BUTTON)
	{
		float dx = 0.1;
		cam.mEye[0] += dx;
		cam.mEye[1] += dx;
		cam.mEye[2] += dx;
	}
	lastX = 0;
	lastY = 0;
}

void idle()
{
	if(play_animation)
	{
		lambda -= speed;
		if(lambda < 0.0)
		{
			lambda = 0.0;
			play_animation = false;
		}
		char text[255];
		sprintf(text, "%1.7f", lambda);
		spin_alpha->set_text(text);
		spin_alpha->redraw();
	}

	glutSetWindow(mainWindow);
	glutPostRedisplay();
}

int main(int argc, char* argv[])
{
	colorBuffer = new unsigned int[WIDTH * HEIGHT * 4];

	new pfxe::MeshManager;

	glutInit(&argc, argv);

	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowSize(WIDTH, HEIGHT);
	glutInitWindowPosition(POS_X, POS_Y);
	mainWindow = glutCreateWindow(WINDOW_NAME);

	GLUI_Master.set_glutDisplayFunc(redraw);
	GLUI_Master.set_glutReshapeFunc(reshape);
	GLUI_Master.set_glutKeyboardFunc(keyboard);
	GLUI_Master.set_glutMouseFunc(mouse);
	GLUI_Master.set_glutIdleFunc(idle);
	glutMotionFunc(mouseMotion);

	glui = GLUI_Master.create_glui_subwindow(mainWindow, GLUI_SUBWINDOW_LEFT);


	spin_s = glui->add_spinner("Speed", GLUI_SPINNER_FLOAT, &speed);

	// Earth texture buttons
	texture_rollout = glui->add_rollout("Earth Texture");
	glui->add_statictext_to_panel(texture_rollout, "Alpha: ");
	spin_alpha = glui->add_statictext_to_panel(texture_rollout, "Alpha");
	char text[255];
	sprintf(text, "%1.7f", lambda);
	spin_alpha->set_text(text);

	spin_s->set_float_limits(0.001, 0.5);
	spin_s->set_speed(0.001);
	spin_s->set_float_val(speed);

	glui->add_button_to_panel(texture_rollout, "Play", CB_PLAY, glui_cb);
	glui->add_button_to_panel(texture_rollout, "Stop", CB_STOP, glui_cb);
	glui->add_button_to_panel(texture_rollout, "Reset", CB_RESET, glui_cb);

	object_type_radio =
			glui->add_radiogroup_to_panel(texture_rollout, &live_object_type);
	glui->add_radiobutton_to_group(object_type_radio, "GL_MODULATE");
	glui->add_radiobutton_to_group(object_type_radio, "GL_REPLACE");
	glui->add_radiobutton_to_group(object_type_radio, "GL_BLEND");
	glui->add_radiobutton_to_group(object_type_radio, "GL_DECAL");


	// Lightmap menu
	lightmap_rollout = glui->add_rollout("Lightmap");
	glui->add_column_to_panel(lightmap_rollout, false);
	glui->add_statictext("\n");
	lightmap_xz_trans = glui->add_translation_to_panel(lightmap_rollout,
			"Translate XZ", GLUI_TRANSLATION_XY, live_object_xz_trans);
	lightmap_xz_trans->set_speed(speed);

	lightmap_size = glui->add_spinner_to_panel(lightmap_rollout,
			"Lightmap size", GLUI_SPINNER_FLOAT, &scale);

	lightmap_size->set_float_limits(1E-6, 10.0);
	lightmap_size->set_speed(0.01);
	lightmap_size->set_float_val(scale);

	glui->add_checkbox_to_panel(lightmap_rollout, "Enable lightmap",
								&enable_lightmap);

	// Cube mapping menu
	cubemap_rollout = glui->add_rollout("Cube map");
	glui->add_button_to_panel(cubemap_rollout, "Update once",
			CB_UPDATE_CUBE_MAP, glui_cb);
	glui->add_checkbox_to_panel(cubemap_rollout, "Continuous update",
								&continuousShots, CB_UPDATE_CUBE_MAP, glui_cb);
	glui->add_checkbox_to_panel(cubemap_rollout, "Debug mode",
									&debug);
	// Quit
	glui->add_statictext("");
	glui->add_button("Quit", 0, (GLUI_Update_CB)exit);



//	glui->hide();

//	glutDisplayFunc(redraw);
//	glutReshapeFunc(reshape);
//	glutKeyboardFunc(keyboard);
//	glutMotionFunc(mouseMotion);
//	glutMouseFunc(mouse);

	initScene();
	glutMainLoop();

	return 0;
}
