/*
 * texture2d.hpp
 *
 *  Created on: Sep 17, 2009
 *      Author: etiene
 *
 *  This file is part of assignment-1.
 *
 *  assignment-1 is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  assignment-1 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with assignment-1.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef TEXTURE2D_HPP_
#define TEXTURE2D_HPP_

#include <rgb_reader.h>

namespace ogl
{

class Texture2D
{
public:
	Texture2D()
	{
		initParam();
	}

	Texture2D(const Texture2D& tex)
	{
		assert(0 && "No copy constructor defined for Texture2D");
	}



protected:
	void initParam();
};


class TextureCubeMapping
{
public:
	TextureCubeMapping()
	{
		initParam();
	}

	TextureCubeMapping(const Texture2D& tex)
	{
		assert(0 && "No copy constructor defined for Texture2D");
	}


	void setCubeTex(GLenum mode, unsigned int* buffer, int width, int height,
			GLenum size = GL_UNSIGNED_BYTE)
	{
		glTexImage2D(mode, 0, GL_RGBA, width, height, 0,
				GL_RGBA, size, buffer);
	}


	void setCubeTex(const char* filename_negative_x,
				    const char* filename_negative_y,
				    const char* filename_negative_z,
				    const char* filename_positive_x,
				    const char* filename_positive_y,
				    const char* filename_positive_z)
	{
		mCurrentImageNX = loadRGBTexture(filename_negative_x);
		mCurrentImageNY = loadRGBTexture(filename_negative_y);
		mCurrentImageNZ = loadRGBTexture(filename_negative_z);
		mCurrentImagePX = loadRGBTexture(filename_positive_x);
		mCurrentImagePY = loadRGBTexture(filename_positive_y);
		mCurrentImagePZ = loadRGBTexture(filename_positive_z);

		glTexImage2D(GL_TEXTURE_CUBE_MAP_NEGATIVE_X, 0, mComponents, mWidth,
				mHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, mCurrentImageNX);
		glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X, 0, mComponents, mWidth,
				mHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, mCurrentImagePX);
		glTexImage2D(GL_TEXTURE_CUBE_MAP_NEGATIVE_Y, 0, mComponents, mWidth,
				mHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, mCurrentImageNY);
		glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_Y, 0, mComponents, mWidth,
				mHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, mCurrentImagePY);
		glTexImage2D(GL_TEXTURE_CUBE_MAP_NEGATIVE_Z, 0, mComponents, mWidth,
				mHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, mCurrentImageNZ);
		glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_Z, 0, mComponents, mWidth,
				mHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, mCurrentImagePZ);

		delete [] mCurrentImageNX;
		delete [] mCurrentImageNY;
		delete [] mCurrentImageNZ;
		delete [] mCurrentImagePX;
		delete [] mCurrentImagePY;
		delete [] mCurrentImagePZ;
	}


	inline
	unsigned int* loadRGBTexture(const char* filename)
	{
		unsigned int* image  =
				read_texture(filename, &mWidth, &mHeight, &mComponents);
		assert(image && "Problem loading image");
		return image;
	}


	unsigned int* mCurrentImageNX;
	unsigned int* mCurrentImageNY;
	unsigned int* mCurrentImageNZ;
	unsigned int* mCurrentImagePX;
	unsigned int* mCurrentImagePY;
	unsigned int* mCurrentImagePZ;
	int mWidth, mHeight, mComponents;

protected:
	void initParam() {};
};



};


#endif /* TEXTURE2D_HPP_ */
