#version 120

varying vec4 p;

void main()
{
	gl_FragColor = p;
}
