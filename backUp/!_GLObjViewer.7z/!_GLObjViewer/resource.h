//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GLObjViewer.rc
//
#define MENU_FIXED_FUNC                 101
#define SHADER_BLINN_PHONG              1000
#define SHADER_NORMAL_MAPPING           1001
#define MENU_FILE_OPEN                  40004
#define MENU_FILE_CLOSE                 40005
#define MENU_FILE_EXIT                  40006
#define MENU_VIEW_FULLSCREEN            40012
#define MENU_VIEW_RESET                 40013
#define MENU_VIEW_TEXTURED              40014
#define MENU_VIEW_WIREFRAME             40015
#define MENU_VIEW_CULLBACKFACES         40017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40018
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
